import React, { Component } from 'react';
import {Title} from './Title';
import './App.css';
import Input from './Input.js';

class App extends Component {
  constructor(){
    super();
    this.state={
     // currentEvent:"-----",
      a :""
     // b:""
    }
   // this.update=this.update.bind(this);
  }
  
  update(){
    this.setState({//currentEvent : e.type,
      a: this.a.value,
     b: this.refs.b.value,
     c: this.c.refs.input.value
    });
  }
  render() {
    return (
      <div className="App">
        <Title text="Hi text here"/>
        <hr/>
        {/* <textarea 
        onKeyPress={this.update}
        onCopy={this.update}
        onCut={this.update}
        onPaste={this.update}
        onFocus={this.update}
        onBlur={this.update}
        onDoubleClick={this.update}
        onTouchStart={this.update}
        onTouchEnd={this.update}
        onTouchMove={this.update}
        cols="30"
        rows="10"
        ></textarea>

        <h1>{this.state.currentEvent}</h1>
        <hr/> */}
        <input ref={node=>this.a=node} type="text" onChange={this.update.bind(this)}></input> {this.state.a}
        <hr/>
        <input ref="b" type="text" onChange={this.update.bind(this)}></input> {this.state.b}
        <hr/>
        <Input ref={component=> this.c = component} update={this.update.bind(this)}/>{this.state.c}
      </div>
    );
  }
}

export default App;
