import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { AdComponent } from './ad.component';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AdService {
  private _url:string="/assets/components/form.json";
  constructor(private http:HttpClient) { }
 public getComponents():Observable<AdComponent[]>{
    return this.http.get<AdComponent[]>(this._url);
  }
}
