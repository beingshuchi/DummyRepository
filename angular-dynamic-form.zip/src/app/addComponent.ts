import { Type } from '@angular/core';

export class AddComponent {
  constructor(public component: Type<any>, public data: any) {}
}
