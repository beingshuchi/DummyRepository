package com.cg.mra.exception;
/**
 * 
 * Class name: Account
 * Number of Methods: 0
 * Number of constructor:2
 * Name of constructor: ccountException(),AccountException(String arg0)
 * Purpose: This is the exception class that throws exception when ever required
 * 
 * Author: Shuchita
 * Date of creation: 11.7.2018
 */
public class AccountException extends Exception {

	public AccountException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AccountException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
}
