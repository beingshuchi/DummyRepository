package com.cg.capstore.exception;

public class SearchException extends Exception {

	public SearchException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SearchException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
