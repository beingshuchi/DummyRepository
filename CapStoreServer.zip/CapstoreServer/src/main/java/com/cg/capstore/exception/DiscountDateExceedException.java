package com.cg.capstore.exception;

public class DiscountDateExceedException extends Exception {

	public DiscountDateExceedException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DiscountDateExceedException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
