package com.cg.capstore.exception;

public class SortingException extends Exception {

	public SortingException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SortingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
