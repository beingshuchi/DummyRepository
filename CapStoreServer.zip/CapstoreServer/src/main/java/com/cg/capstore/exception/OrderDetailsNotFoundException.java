package com.cg.capstore.exception;

public class OrderDetailsNotFoundException extends Exception {

	public OrderDetailsNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderDetailsNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
