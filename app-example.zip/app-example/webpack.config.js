const path=require('path');

const HWP=require('html-webpack-plugin');

module.exports={
    entry: path.join(__dirname,'/src/index.js'),//starting point of application
    output:{
        filname: "build.js",
        path: path.join(__dirname,'/dist'),
        publicPath: '/'
    },//automatically building the file during production
    devServer: {
        inline: false,
        contentBase: "./dist",
    },
    module:{
        rules:[{
            test:/\.js$/,
            exclude:/node_module/,
            load: "babel-loader"
        },
        {
            test:/\.scss$/,
            exclude:"node_modules",
            use:["raw-loader","sass-loader",'postcss-loader']
        }]
    },//asks webpack to look all .js files excluding those in /node_module/

    plugins:[
        new HWP({
            template: path.join(__dirname,'/src/index.html')
        })//for the purpose of bundling or transpiling
    ]
}