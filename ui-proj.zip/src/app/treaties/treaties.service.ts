import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { ITreaties } from '../shared/treaties.model';

@Injectable()
export class treatiesService {

    constructor(private http: HttpClient) { }

    getTreaties() {
    return this.http.get<any>('assets/sampleData/sampleTreaties.json')
      .toPromise()
      .then(res => <ITreaties[]>res.data)
      .then(data => { return data; });
    }
}