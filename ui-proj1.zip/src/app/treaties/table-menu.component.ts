import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { MenubarModule, MenuItem } from 'primeng/primeng';
@Component({
    selector: 'table-menu',
    template: '<p-menubar [model]="MenuData">'
})
export class TableMenuComponent {
    @Input() MenuData: MenuItem[];
    constructor() { 
        
    }
}