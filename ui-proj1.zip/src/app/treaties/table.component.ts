import {Component,OnInit, ViewEncapsulation} from '@angular/core';
import {ITreaties} from '../shared/treaties.model';
import {treatiesService} from './treaties.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MenuItem, SortEvent } from 'primeng/api';


@Component({
    selector: 'app-table',
    template:   '<p-menubar model="items"></p-menubar>',
    templateUrl: './treaties.component.html',
    styleUrls: ['./treaties.component.css']
})
export class tableComponent implements OnInit 
{
    items: MenuItem[];

    treatyForm : FormGroup;

    collapsed = true;

     
  public filtered: Map<string, boolean> = new Map<string, boolean>();
  public filter = {
    ledger: []
  };

    allStatus = [
      { label : 'Study', value: 'study'},
      { label : 'Finalized', value: 'finalized'},
      { label : 'Prospect', value: 'prospect'},
      { label : 'To Validate', value: 'toValidate'},
      { label : 'Authorized', value: 'authorized'},
      { label : 'Renewed', value: 'renewed'},
      { label : 'accepted', value: 'accepted'}
    ]
  
    
    loading: boolean;

    treaties: ITreaties[];
    
    cols: any[];

   
    
    constructor(private treatiesService: treatiesService, private fb: FormBuilder) { }

    ngOnInit() {
        this.loading = true;
        setTimeout(() => {
            this.treatiesService.getTreaties().then(treaties => this.treaties = treaties);
            this.loading = false;
        }, 1000);0
        
        this.treatyForm = this.fb.group ({
            ledgerName:[''],
            uwUnit:[''],
            cedentNo: [''],
            cedentName: [''],
            treatyNo: ['', [Validators.required, Validators.minLength(1)]],
            treatyName: [[''], [Validators.required, Validators.minLength(1)]],
            treatyStatus: ['']
           })
         
        this.cols = [
            {field: 'ledger', header: 'Ledger'},
            {field: 'ledgerName', header: 'LedgerName'},
            {field: 'uwUnit', header: 'UwUnit'},
            {field: 'cedentNo', header: 'CedentNo'},
            {field: 'cedentName', header: 'CedentName'},
            {field: 'treatyNo', header: 'TreatyNo'},
            {field: 'treatyName', header: 'TreatyName'},
            {field: 'lastUWY', header: 'LastUWY'},
            {field: 'status', header: 'Status'}
        ];

        // this.items = [
        //     {
        //         label: 'Ledger',
        //         items: [{
        //                 label: 'Sort', 
        //                 icon: 'fa fa-sort',
        //                 command: (event: any) => {
        //                     this.customSort(event);
        //                 }
        //             },
        //             {separator: true},
        //             {label: 'Filter', icon: 'fa fa-filter'}
        //         ]
        //     }]
        this.items = [
            {label: 'Sort'},
            {label: 'Filter'},
            {label: 'Options'}
        ];
    }

    onSubmit()
    {
      alert(JSON.stringify(this.treatyForm.value));
    }
  
     hasFormError(){
      return !this.treatyForm.valid;
    }

    /*
  fieldErrors(field: string)
  {
    let controlState = this.treatyForm.controls[field];
    return (controlState.errors) ? controlState.errors:
    null;
  } */

  //treatyResults: Array = [];
   
   /* searchLedger(event): void {
      this.treatyResults = this.treaties.filter(c => c.ledger.startsWith(event.query));
   } */

   customSort(event: SortEvent) {
    event.data.sort((data1, data2) => {
        let value1 = data1[event.field];
        let value2 = data2[event.field];
        let result = null;

        if (value1 == null && value2 != null)
            result = -1;
        else if (value1 != null && value2 == null)
            result = 1;
        else if (value1 == null && value2 == null)
            result = 0;
        else if (typeof value1 === 'string' && typeof value2 === 'string')
            result = value1.localeCompare(value2);
        else
            result = (value1 < value2) ? -1 : (value1 > value2) ? 1 : 0;

        return (event.order * result);
    });
}
}