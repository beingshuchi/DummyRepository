import React, { Component } from 'react';
import logo from './logo.svg';
import './Components/Question';

class App extends Component {
  constructor(props){
    super(props);
    this.state={
      field:""
    };
  }
  render() {
    return (
    <div>
      
    </div>

    );
  }
}

export default App;
