package com.example.controller;

import java.io.InputStream;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.example.beans.AdminBean;
import com.example.beans.Message;

@Controller
public class JspController {

	@RequestMapping(value="/welcome{id}")
	public String showWelcomePage(@RequestParam Integer id, ModelMap model){
		
		RestTemplate restTemplate = new RestTemplate();
		Message message = restTemplate.getForObject("http://localhost:9090/getmessage?id="+id, Message.class);
		System.out.println(message);
		model.put("message", message);
		return "welcome";
	}
	@RequestMapping(value="/alogin")
	public String adminLgin(@RequestParam String email,@RequestParam String password, ModelMap model){
		
		RestTemplate restTemplate = new RestTemplate();
		AdminBean admin = restTemplate.getForObject("http://localhost:9191/adminLogin?email="+email+"&password="+password, AdminBean.class);
		//System.out.println(message);
		model.put("admin", admin);
		return "Admin-home";
	}
}
