package com.cg.step;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.poo.HotelBookingBeans;
import com.cg.poo.HotelForm;
import com.cg.util.DriverUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelStep {
	private WebDriver driver;
	private HotelBookingBeans hotelBeans;
	private DriverUtil driverUtil;
	private HotelForm form;
	String actualMessage, expectedMessage;

	@Test
	public void test() throws Throwable {
		user_is_Login_page();
		user_clicks_Login_button_after_entering_invalid_UserName_and_Password();
		valid_login_Please_try_again_message_should_display();
		user_clicks_Login_button_after_entering_valid_UserName_and_Password();
		user_is_navigated_to_next_page();
		user_is_on_hotel_room_booking_page();
		user_clicks_Confirm_Booking_button_without_entering_FirstName();
		please_fill_the_First_Name_message_should_display();
		user_clicks_Confirm_Booking_button_without_entering_LastName();
		please_fill_the_Last_Name_message_should_display();
		user_clicks_Confirm_Booking_button_without_entering_Email();
		please_fill_the_Email_message_should_display();
		user_clicks_Confirm_Booking_button_after_entering_invalid_Email();
		please_enter_valid_Email_Id_message_should_display();
		user_clicks_Confirm_Booking_button_without_entering_Mobile_No();
		please_fill_the_Mobile_No_message_should_display();
		user_clicks_Confirm_Booking_button_after_entering_invalid_Mobile_No();

		please_enter_valid_Contact_no_message_should_display();

		user_clicks_Confirm_Booking_button_without_selecting_City();

		please_select_city_message_should_display();

		user_clicks_Confirm_Booking_button_without_selecting_State();

		please_select_state_message_should_display();

		user_clicks_Confirm_Booking_button_without_entering_Card_Holder_Name();
		please_fill_the_Card_holder_name_message_should_display();
		user_clicks_Confirm_Booking_button_without_entering_Debit_Card_Number();
		please_fill_the_Debit_card_Number_message_should_display();
		user_clicks_Confirm_Booking_button_without_entering_CVV();
		please_fill_the_CVV_message_should_display();
		user_clicks_Confirm_Booking_button_without_entering_Expiration_Month();
		please_fill_expiration_month_message_should_display();
		user_clicks_Confirm_Booking_button_without_entering_Expiration_Year();
		please_fill_the_expiration_year_message_should_display();
		user_clicks_Confirm_Booking_button_after_entering_Valid_set_of_information();
		booking_Completed_message_should_display();
	}

	@Before
	public void Initialization() {
		driverUtil = new DriverUtil();
		driver = driverUtil.initializeDriver("CHROME");
		hotelBeans = new HotelBookingBeans();
		form = new HotelForm();
		PageFactory.initElements(driver, hotelBeans);

	}

	@Given("^User is Login page$")
	public void user_is_Login_page() throws Throwable {
		driver.get("D:\\BDDWorkspace\\HotelManagement\\WebContent\\login.html");
	}

	@When("^User clicks 'Login' button after entering invalid 'UserName' and 'Password'$")
	public void user_clicks_Login_button_after_entering_invalid_UserName_and_Password()
			throws Throwable {
		hotelBeans.setUsername("Capgemini");
		hotelBeans.setPassword("capg13234");
		Thread.sleep(1000);
		hotelBeans.onLogin();
		Thread.sleep(2000);

	}

	@Then("^'valid login! Please try again!' message should display$")
	public void valid_login_Please_try_again_message_should_display()
			throws Throwable {
		actualMessage = driver.switchTo().alert().getText();
		expectedMessage = "Invalid login! Please try again!";
		Assert.assertEquals(actualMessage, expectedMessage);

	}

	@When("^User clicks 'Login' button after entering valid 'UserName' and 'Password'$")
	public void user_clicks_Login_button_after_entering_valid_UserName_and_Password()
			throws Throwable {
		driver.switchTo().alert().dismiss();
		hotelBeans.setUsername("capgemini");
		hotelBeans.setPassword("capg1234");
		Thread.sleep(2000);
	}

	@Then("^User is navigated to next page$")
	public void user_is_navigated_to_next_page() throws Throwable {
		hotelBeans.onLogin();
		Thread.sleep(2000);
	}

	@Given("^User is on hotel room booking page$")
	public void user_is_on_hotel_room_booking_page() throws Throwable {
		PageFactory.initElements(driver, form);
	}

	@When("^User clicks 'Confirm Booking' button without entering 'FirstName'$")
	public void user_clicks_Confirm_Booking_button_without_entering_FirstName()
			throws Throwable {
		form.onPayment();

	}

	@Then("^'Please fill the First Name' message should display$")
	public void please_fill_the_First_Name_message_should_display()
			throws Throwable {
		actualMessage = driver.switchTo().alert().getText();
		expectedMessage = "Please fill the First Name";
		Assert.assertEquals(actualMessage, expectedMessage);

		Thread.sleep(2000);

	}

	@When("^User clicks 'Confirm Booking' button without entering 'LastName'$")
	public void user_clicks_Confirm_Booking_button_without_entering_LastName()
			throws Throwable {
		driver.switchTo().alert().dismiss();
		form.setFname("Shruti");
		Thread.sleep(2000);
		form.onPayment();
	}

	@Then("^'Please fill the Last Name' message should display$")
	public void please_fill_the_Last_Name_message_should_display()
			throws Throwable {
		actualMessage = driver.switchTo().alert().getText();
		expectedMessage = "Please fill the Last Name";
		Assert.assertEquals(actualMessage, expectedMessage);
		Thread.sleep(2000);
	}

	@When("^User clicks 'Confirm Booking' button without entering 'Email'$")
	public void user_clicks_Confirm_Booking_button_without_entering_Email()
			throws Throwable {
		driver.switchTo().alert().dismiss();
		form.setLname("agarwal");
		Thread.sleep(2000);
		form.onPayment();
	}

	@Then("^'Please fill the Email' message should display$")
	public void please_fill_the_Email_message_should_display() throws Throwable {
		actualMessage = driver.switchTo().alert().getText();
		expectedMessage = "Please fill the Email";
		Assert.assertEquals(actualMessage, expectedMessage);
		Thread.sleep(2000);
	}

	@When("^User clicks 'Confirm Booking' button after entering invalid 'Email'$")
	public void user_clicks_Confirm_Booking_button_after_entering_invalid_Email()
			throws Throwable {
		driver.switchTo().alert().dismiss();
		form.setEmail("abcgmail.com");
		form.onPayment();
		Thread.sleep(2000);
	}

	@Then("^'Please enter valid Email Id\\.' message should display$")
	public void please_enter_valid_Email_Id_message_should_display()
			throws Throwable {

		actualMessage = driver.switchTo().alert().getText();
		expectedMessage = "Please enter valid Email Id.";
		Assert.assertEquals(actualMessage, expectedMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
		form.setEmail("abc@gmail.com");
	}

	@When("^User clicks 'Confirm Booking' button without entering 'Mobile No'$")
	public void user_clicks_Confirm_Booking_button_without_entering_Mobile_No()
			throws Throwable {
		form.onPayment();
	}

	@Then("^'Please fill the Mobile No\\.' message should display$")
	public void please_fill_the_Mobile_No_message_should_display()
			throws Throwable {
		actualMessage = driver.switchTo().alert().getText();
		expectedMessage = "Please fill the Mobile No.";
		Assert.assertEquals(actualMessage, expectedMessage);
		Thread.sleep(2000);
	}

	@When("^User clicks 'Confirm Booking' button  after entering invalid 'Mobile No'$")
	public void user_clicks_Confirm_Booking_button_after_entering_invalid_Mobile_No()
			throws Throwable {
		driver.switchTo().alert().dismiss();
		form.setPhone("5060392421");
		form.onPayment();
		Thread.sleep(2000);
	}

	@Then("^'Please enter valid Contact no\\.' message should display$")
	public void please_enter_valid_Contact_no_message_should_display()
			throws Throwable {
		actualMessage = driver.switchTo().alert().getText();
		expectedMessage = "Please enter valid Contact no.";
		Assert.assertEquals(actualMessage, expectedMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
		form.setPhone("7060392421");
		Thread.sleep(2000);
	}

	@When("^User clicks 'Confirm Booking' button without selecting 'City'$")
	public void user_clicks_Confirm_Booking_button_without_selecting_City()
			throws Throwable {
		form.onPayment();

	}

	@Then("^'Please select city' message should display$")
	public void please_select_city_message_should_display() throws Throwable {
		actualMessage = driver.switchTo().alert().getText();
		expectedMessage = "Please select city";
		Assert.assertEquals(actualMessage, expectedMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
		form.setAddress("abc hon gali khan masdadashb");
		form.setCity("Bangalore");
		Thread.sleep(2000);
	}

	@When("^User clicks 'Confirm Booking' button without selecting 'State'$")
	public void user_clicks_Confirm_Booking_button_without_selecting_State()
			throws Throwable {
		form.onPayment();
	}

	@Then("^'Please select state' message should display$")
	public void please_select_state_message_should_display() throws Throwable {
		actualMessage = driver.switchTo().alert().getText();
		expectedMessage = "Please select state";
		Assert.assertEquals(actualMessage, expectedMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
		form.setState("Karnataka");
		form.setGuest("1");
		Thread.sleep(1000);
	}

	@When("^User clicks 'Confirm Booking' button without entering 'Card Holder Name'$")
	public void user_clicks_Confirm_Booking_button_without_entering_Card_Holder_Name()
			throws Throwable {
		form.onPayment();
	}

	@Then("^'Please fill the Card holder name' message should display$")
	public void please_fill_the_Card_holder_name_message_should_display()
			throws Throwable {
		actualMessage = driver.switchTo().alert().getText();
		expectedMessage = "Please fill the Card holder name";
		Assert.assertEquals(actualMessage, expectedMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
		form.setCardHolderName("Shruti Agarwal");
	}

	@When("^User clicks 'Confirm Booking' button without entering 'Debit Card Number'$")
	public void user_clicks_Confirm_Booking_button_without_entering_Debit_Card_Number()
			throws Throwable {
		form.onPayment();
	}

	@Then("^'Please fill the Debit card Number' message should display$")
	public void please_fill_the_Debit_card_Number_message_should_display()
			throws Throwable {
		actualMessage = driver.switchTo().alert().getText();
		expectedMessage = "Please fill the Debit card Number";
		Assert.assertEquals(actualMessage, expectedMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
		form.setCardNumber("123412341234");
		Thread.sleep(1000);
	}

	@When("^User clicks 'Confirm Booking' button without entering 'CVV'$")
	public void user_clicks_Confirm_Booking_button_without_entering_CVV()
			throws Throwable {
		form.onPayment();
	}

	@Then("^'Please fill the CVV' message should display$")
	public void please_fill_the_CVV_message_should_display() throws Throwable {
		actualMessage = driver.switchTo().alert().getText();
		expectedMessage = "Please fill the CVV";
		Assert.assertEquals(actualMessage, expectedMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
		form.setCardCVV("550");
		Thread.sleep(1000);
	}

	@When("^User clicks 'Confirm Booking' button without entering 'Expiration Month'$")
	public void user_clicks_Confirm_Booking_button_without_entering_Expiration_Month()
			throws Throwable {
		form.onPayment();
	}

	@Then("^'Please fill expiration month' message should display$")
	public void please_fill_expiration_month_message_should_display()
			throws Throwable {
		actualMessage = driver.switchTo().alert().getText();
		expectedMessage = "Please fill expiration month";
		Assert.assertEquals(actualMessage, expectedMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
		form.setCardMonth("10");
		Thread.sleep(1000);
	}

	@When("^User clicks 'Confirm Booking' button without entering 'Expiration Year'$")
	public void user_clicks_Confirm_Booking_button_without_entering_Expiration_Year()
			throws Throwable {
		form.onPayment();
	}

	@Then("^'Please fill the expiration year' message should display$")
	public void please_fill_the_expiration_year_message_should_display()
			throws Throwable {
		actualMessage = driver.switchTo().alert().getText();
		expectedMessage = "Please fill the expiration year";
		Assert.assertEquals(actualMessage, expectedMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
		form.setCardYear("2019");
		Thread.sleep(2000);
	}

	@When("^User clicks 'Confirm Booking' button after entering Valid set of information$")
	public void user_clicks_Confirm_Booking_button_after_entering_Valid_set_of_information()
			throws Throwable {
		form.onPayment();
	}

	@Then("^'Booking Completed!' message should display$")
	public void booking_Completed_message_should_display() throws Throwable {
		Thread.sleep(2000);

	}

	@After
	public void closeDriver() {
		driver.quit();
	}
}
