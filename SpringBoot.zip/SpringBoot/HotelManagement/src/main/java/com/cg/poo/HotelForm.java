package com.cg.poo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class HotelForm {

	@FindBy(how = How.ID, id = "txtFirstName")
	private WebElement fname;

	@FindBy(how = How.ID, id = "txtLastName")
	private WebElement lname;

	@FindBy(how = How.NAME, name = "Email")
	private WebElement email;

	@FindBy(how = How.NAME, name = "Phone")
	private WebElement phone;

	@FindBy(how = How.NAME, name = "ttaddr")
	private WebElement address;

	@FindBy(how = How.NAME, name = "city")
	private WebElement city;

	@FindBy(how = How.NAME, name = "state")
	private WebElement state;

	@FindBy(how = How.NAME, name = "persons")
	private WebElement guest;

	@FindBy(how = How.ID, id = "txtCardholderName")
	private WebElement cardHolderName;

	@FindBy(how = How.ID, id = "txtDebit")
	private WebElement cardNumber;

	@FindBy(how = How.ID, id = "txtCvv")
	private WebElement cardCVV;

	@FindBy(how = How.ID, id = "txtMonth")
	private WebElement cardMonth;

	@FindBy(how = How.ID, id = "txtYear")
	private WebElement cardYear;

	@FindBy(how = How.ID, id = "btnPayment")
	private WebElement payment;

	public void onPayment() {
		payment.click();
	}

	public String getFname() {
		return fname.getAttribute("value");
	}

	public void setFname(String fname) {
		this.fname.sendKeys(fname);
	}

	public String getLname() {
		return lname.getAttribute("value");
	}

	public void setLname(String lname) {
		this.lname.sendKeys(lname);
	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.clear();
		this.email.sendKeys(email);
	}

	public String getPhone() {
		return phone.getAttribute("value");
	}

	public void setPhone(String phone) {
		this.phone.clear();
		this.phone.sendKeys(phone);

	}

	public String getAddress() {
		return address.getAttribute("value");
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public String getCity() {
		return new Select(this.city).getFirstSelectedOption().getText();
	}

	public void setCity(String city) {
		new Select(this.city).selectByVisibleText(city);
	}

	public String getState() {
		return new Select(this.state).getFirstSelectedOption().getText();
	}

	public void setState(String state) {
		new Select(this.state).selectByVisibleText(state);
	}

	public String getGuest() {
		return new Select(this.guest).getFirstSelectedOption().getText();
	}

	public void setGuest(String guest) {
		new Select(this.guest).selectByVisibleText(guest);
	}

	public String getCardHolderName() {
		return cardHolderName.getAttribute("value");
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);
	}

	public String getCardNumber() {
		return cardNumber.getAttribute("value");
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber.sendKeys(cardNumber);
	}

	public String getCardCVV() {
		return cardCVV.getAttribute("value");
	}

	public void setCardCVV(String cardCVV) {
		this.cardCVV.sendKeys(cardCVV);
	}

	public String getCardMonth() {
		return cardMonth.getAttribute("value");
	}

	public void setCardMonth(String cardMonth) {
		this.cardMonth.sendKeys(cardMonth);
	}

	public String getCardYear() {
		return cardYear.getAttribute("value");
	}

	public void setCardYear(String cardYear) {
		this.cardYear.sendKeys(cardYear);
	}

}
