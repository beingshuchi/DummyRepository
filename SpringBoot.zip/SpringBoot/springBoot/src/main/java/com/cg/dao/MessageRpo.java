package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.model.Mesage;
@Repository
public interface MessageRpo extends JpaRepository<Mesage, Integer>{
	@Query("Select m from Mesage m  WHERE m.text = :g ")
	public Mesage getMessageByText(@Param(value="g")String text);
	@Query("Select m from Mesage m INNER JOIN m.sender s   WHERE s.name = :g ")
	public Mesage getMessageBySender(@Param(value="g")String name);
}
