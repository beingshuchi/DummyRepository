package com.cg.springBoot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dao.MessageRpo;
import com.cg.model.Mesage;
import com.cg.model.Sender;

@RestController
public class SpringBootController {
	
	@Autowired
	private MessageRpo repo;
	
	
	@RequestMapping(value="/")
	public String sayHello() {
		return"Hello";
	}
	
	@RequestMapping(value="/text")
	public Mesage sendMessage() {
		Mesage m=new Mesage();
		Sender s= new Sender();
		s.setName("Shuchita");
		m.setText("Hello this is from spring controller");
		m.setSender(s);
		return m;
	}
	@RequestMapping(value="/sendMessage",method=RequestMethod.POST)
	public Mesage receiveMessage(@RequestBody Mesage m) {
		repo.save(m);
		return m;
	}
	@RequestMapping(value="/sendSimple",method=RequestMethod.GET)
	public String recieveSimpleMessage(String s) {
		
		return s;
	}
	@RequestMapping(value="/getMessage")
	public Mesage getMessage(int id) {
		return repo.getOne(id);
	}
	
	
	@RequestMapping(value="/getMessageByText")
	public Mesage getMessageByText(String text) {
		return repo.getMessageByText(text);
	}
	
	@RequestMapping(value="/getMessageBySender")
	public Mesage getMessageBySender(String name) {
		return repo.getMessageBySender(name);
	}
}
