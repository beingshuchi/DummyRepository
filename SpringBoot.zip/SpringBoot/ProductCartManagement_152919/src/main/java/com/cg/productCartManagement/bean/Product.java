package com.cg.productCartManagement.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/**
 * 
 * Class name: Product
 * Number of Methods: 8
 * Purpose: This is the bean class that contains the template for the product Details
 * Name of methods: public void setId(String id) , public String getId() ,
 *                  public String getName() , public void setName(String name), 
 *                  public String getModel(),public void setModel(String model) ,
 *                  public long getPrice(), public void setPrice(long price)
 * Author: Shuchita
 * Date of creation: 8.8.2018
 * 
 *
 */



@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
@Entity
@Table(name="product")
public class Product{
	@Id
	@Column(name="id")
	private String id;
	@Column(name="name")
	private String name;
	@Column(name="model")
	private String model;
	@Column(name="price")
	private long price;
	
	public void setId(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public long getPrice() {
		return price;
	}
	public void setPrice(long price) {
		this.price = price;
	}
	
	
}
