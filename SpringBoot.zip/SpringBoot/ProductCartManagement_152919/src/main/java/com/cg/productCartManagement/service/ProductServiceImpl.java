package com.cg.productCartManagement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.productCartManagement.bean.Product;
import com.cg.productCartManagement.exception.ProductException;
import com.cg.productCartManagement.repo.IProductRepo;

/**
 * 
 * Class name: Product
 * Number of Methods: 8
 * Purpose: This is the bean class that contains the template for the product Details
 * Name of methods:Product createProduct(Product product) throws ProductException,
	               Product updateProduct(Product product) throws ProductException,
	               boolean delete(String id)throws ProductException,
	               List<Product> viewProducts() throws ProductException,
	               Product findById(String id)throws ProductException;
 * Author: Shuchita
 * Date of creation: 8.8.2018
 * 
 *
 */

@Service(value="service")
public class ProductServiceImpl implements IProductService{
	
	/*
	 * Annotating with autowired so that spring can create the object for the repository
	 * */
	@Autowired
	private IProductRepo repo;

	/*
	 * This method creates a new product in the repository
	 * It also validates the input given by the client
	 * */
	
	@Override
	@Transactional
	public Product createProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		if(null==product.getId() || product.getId().isEmpty()) {
			throw new ProductException("Id cannot be left empty");
		}
		else {
			if(!product.getId().matches("[a-z]{1,4}[0-9]{2,}")) {
				throw new ProductException("Please enter id with min 1 alphabet and min 2 numbers");
			}
		}
		if(null==product.getName() || product.getName().isEmpty()) {
			throw new ProductException("Name cannot be left empty");
		}
		else {
			if(!product.getName().matches("[A-Z]{1}[a-z]{1,}")) {
				throw new ProductException("Please enter name of the product with capital and the name should contain atleast one small letter");
			}
		}
		if(null==product.getModel() || product.getModel().isEmpty()) {
			throw new ProductException("Model name cannot be left empty");
		}
		else {
			if(!product.getName().matches("[A-za-z0-9]{3,}")) {
				throw new ProductException("Please enter name of the model with alpabets and numbers only. the name must have min of 3 numbers or alphabets");
			}
		}
		if(product.getPrice()<=0){
			throw new ProductException("Price must me greater than 0");
		}
		
		
		return repo.save(product);
	}
	
	/*
	 * This method updates the existing product in the repository
	 * It also validates the input given by the client
	 * If the product with the id set by the user does not exists,
	 *  it will throw an exception
	 * */

	@Override
	@Transactional
	public Product updateProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		if(null==product.getId() || product.getId().isEmpty()) {
			throw new ProductException("Id cannot be left empty");
		}
		else {
			if(!product.getId().matches("[a-z]{1,4}[0-9]{2,}")) {
				throw new ProductException("Please enter id with min 1 alphabet and min 2 numbers");
			}
		}
		if(null==product.getName() || product.getName().isEmpty()) {
			throw new ProductException("Name cannot be left empty");
		}
		else {
			if(!product.getName().matches("[A-Z]{1}[a-z]{1,}")) {
				throw new ProductException("Please enter name of the product with capital and the name should contain atleast one small letter");
			}
		}
		if(null==product.getModel() || product.getModel().isEmpty()) {
			throw new ProductException("Model name cannot be left empty");
		}
		else {
			if(!product.getName().matches("[A-za-z0-9]{3,}")) {
				throw new ProductException("Please enter name of the model with alpabets and numbers only. the name must have min of 3 numbers or alphabets");
			}
		}
		if(product.getPrice()<=0){
			throw new ProductException("Price must me greater than 0");
		}
		
		Product p= repo.find(product.getId());
		if(null!=p) {
		p.setName(product.getName());
		p.setModel(product.getModel());
		p.setPrice(product.getPrice());
		repo.save(p);
		return p;
		}
		else {
			throw new ProductException("The person with the id "+product.getId()+" does not exists.");
		}
	}
	
	/*
	 * This method deletes the existing product in the repository
	 * It also validates the input given by the client
	 *  If the product with the id set by the user does not exists,
	 *  it will throw an exception
	 * */

	@Override
	@Transactional
	public boolean delete(String id) throws ProductException {
		if(null==id || id.isEmpty()) {
			throw new ProductException("Id cannot be left empty");
		}
		else {
			if(!id.matches("[a-z]{1,4}[0-9]{2,}")) {
				throw new ProductException("Please enter id with min 1 alphabet and min 2 numbers");
			}
		}
		boolean status=false;
		Product product=repo.find(id);
		if(null!=product) {
			repo.deleteEmp(id);
				status=true;
				if(status) {
					return status;
				}
				else {
					throw new ProductException("Could not delete the person with the id "+id);
				}
		}
		else {
			throw new ProductException("The person with the id "+id+" does not exists.");
		}
		
		
		
	}
	/*
	 * This method sends all the existing products in the repository.
	 *  If there are no products in the database, it will throw an exception
	 * */

	@Override
	public List<Product> viewProducts() throws ProductException {
		// TODO Auto-generated method stub
		List<Product>products=repo.findAll();
		if(null!=products) {
			return products;
		}
		else {
			throw new ProductException("There are no products available. ");
		}
		
	}
	/*
	 * This method finds the existing product in the repository based on the id
	 * It also validates the input given by the client
	 *  If the product with the id set by the user does not exists,
	 *  it will throw an exception
	 * */
	@Override
	public Product findById(String id) throws ProductException {
		// TODO Auto-generated method stub
		if(null==id || id.isEmpty()) {
			throw new ProductException("Id cannot be left empty");
		}
		else {
			if(!id.matches("[a-z]{1,4}[0-9]{2,}")) {
				throw new ProductException("Please enter id with min 1 alphabet and min 2 numbers");
			}
		}
		Product product=repo.find(id);
		if(null!=product) {
			return product;
		}
		else {
			throw new ProductException("The person with the id "+id+" does not exists.");
		}
	}
	
}
