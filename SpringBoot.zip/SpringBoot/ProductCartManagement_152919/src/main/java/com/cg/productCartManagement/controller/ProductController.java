package com.cg.productCartManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.productCartManagement.bean.Product;
import com.cg.productCartManagement.exception.ProductException;
import com.cg.productCartManagement.service.IProductService;
/**
 * 
 * Class name: ProductController
 * Number of Methods: 5
 * Purpose: This is the back controller to forward the invoked method from the dispatcher 
 *          servlet to the service and send back the model to the dispatcher servlet
 * Name of methods:Product save(@RequestBody Product product) throws ProductException,
 *                 Product update(@PathVariable String id, @RequestBody Product product) throws ProductException,
 *                 boolean delete(@PathVariable(value="id")String id) throws ProductException ,
 *                 public List<Product> viewAll() throws ProductException,
 *                 public Product findById(String id) throws ProductException
 * Author: Shuchita
 * Date of creation: 8.8.2018
 * 
 *
 */
@RestController
public class ProductController {
	@Autowired
	private IProductService service;
	
	/*
	 * This method is required to save the product by invoking the creaateProduct method in service.
	 * */
	
	@RequestMapping(value="/create",  method=RequestMethod.POST)
	Product save(@RequestBody Product product) throws ProductException {
		try {
			service.createProduct(product);
			
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			throw new ProductException(e.getMessage());
		}
		return product;
	}
	
	/*
	 * This method is required to update the product by invoking the updateProduct method in service.
	 * */
	
	@RequestMapping(value="/update/{id}" , method=RequestMethod.PUT)
	Product update(@PathVariable String id, @RequestBody Product product) throws ProductException {
		Product p=null;
		try {
			p = service.updateProduct(product);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			throw new ProductException(e.getMessage());
		}
		return p;
	}
	/*
	 * This method is required to delete the product by invoking the deleteProduct method in service.
	 * */
	
	@RequestMapping(value="/delete/{id}",method=RequestMethod.DELETE)
	boolean delete(@PathVariable(value="id")String id) throws ProductException {
		boolean status=false;
		try {
			status = service.delete(id);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			throw new ProductException(e.getMessage());
		}
		return status;
	}
	/*
	 * This method is required to view all the product by invoking the viewAllProduct method in service.
	 * */
	@RequestMapping(value="/view",method=RequestMethod.GET)
	public List<Product> viewAll() throws ProductException {
		// TODO Auto-generated method stub
		List<Product> productList=null;
		try {
			productList = service.viewProducts();
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			throw new ProductException(e.getMessage());
		}
		return productList;
	}
	/*
	 * This method is required to find the product by invoking the findById method in service.
	 * */
	
	@RequestMapping(value="/find", method=RequestMethod.GET)
	public Product findById(String id) throws ProductException {
		// TODO Auto-generated method stub
		Product product;
		
			try {
				product = service.findById(id);
				return product;
			} catch (ProductException e) {
				// TODO Auto-generated catch block
				
					throw new ProductException(e.getMessage());
				
			}
	}
}
