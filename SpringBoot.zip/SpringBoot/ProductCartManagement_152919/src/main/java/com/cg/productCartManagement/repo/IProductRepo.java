package com.cg.productCartManagement.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cg.productCartManagement.bean.Product;
import com.cg.productCartManagement.exception.ProductException;

/**
 * 
 * Interface name:IProductRepo
 * Number of Methods: 2
 * Purpose: This repository interacts with the database
 * Name of methods:Product find(@Param(value="id") String id) throws ProductException;,
 *                void deleteEmp(@Param(value="id")String id)throws ProductException; 
 * Author: Shuchita
 * Date of creation: 8.8.2018
 * 
 *
 */

@Repository
public interface IProductRepo extends JpaRepository<Product, String> {
	/*
	 * The query written finds the product by the given id
	 * */
	@Query("SELECT p FROM Product p WHERE p.id=:id")
	Product find(@Param(value="id") String id) throws ProductException;
	
	/*
	 * The query written deletes the product by the given id
	 * */
	@Modifying
	@Query(value="delete from Product p where p.id =:id")
	void deleteEmp(@Param(value="id")String id)throws ProductException;
}
