package com.cg.productCartManagement.exception;
/**
 * 
 * Class name: ProductExcrption
 * Purpose: This is an exception class to throw exceptions
 * Author: Shuchita
 * Date of creation: 8.8.2018
 * 
 *
 */
public class ProductException extends Exception{

	public ProductException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
}
