package com.cg.productCartManagement.service;

import java.util.List;

import com.cg.productCartManagement.bean.Product;
import com.cg.productCartManagement.exception.ProductException;

/**
 * 
 * Interface name:IProductService
 * Number of Methods: 5
 * Purpose: This service interacts with the repository and the controller
 * Name of methods:Product createProduct(Product product) throws ProductException,
	               Product updateProduct(Product product) throws ProductException,
	               boolean delete(String id)throws ProductException,
	               List<Product> viewProducts() throws ProductException,
	               Product findById(String id)throws ProductException;
 * Author: Shuchita
 * Date of creation: 8.8.2018
 * 
 *
 */

public interface IProductService {
	Product createProduct(Product product) throws ProductException;
	Product updateProduct(Product product) throws ProductException;
	boolean delete(String id)throws ProductException;
	List<Product> viewProducts() throws ProductException;
	Product findById(String id)throws ProductException;
}
