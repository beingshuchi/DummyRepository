package com.capgemini.service;

public interface ISignUp {

	public void signUp(String email, String psw, String psw_repeat);
	public String encrypt(String password);
	public boolean login(String email, String psw);
	

}
