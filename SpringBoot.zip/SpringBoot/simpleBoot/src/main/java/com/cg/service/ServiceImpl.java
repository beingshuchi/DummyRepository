package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.User;
import com.cg.repo.IRepo;
@Service
public class ServiceImpl implements Iservice {
	@Autowired
 private IRepo repo;
	
	@Override
	@Transactional
	public User save(User u) {
		// TODO Auto-generated method stub
		repo.save(u);
		return u;
	}

}
