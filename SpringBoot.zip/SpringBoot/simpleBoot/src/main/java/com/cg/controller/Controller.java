package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.bean.User;
import com.cg.service.Iservice;

@RestController
public class Controller {
	@Autowired
	private Iservice service;
	@RequestMapping(value="/saveUser",  method=RequestMethod.POST)
	public User getUser(User user) {
		service.save(user);
		System.out.print(user.getName());
		System.out.print(" : "+user.getPassword());
		return user;
		
	}
}
