package com.cg.service;

import com.cg.bean.User;

public interface Iservice {
	User save(User u);
}
