package com.cg.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Day;
import com.cg.dao.SportsRepo;
import com.cg.service.SportsService;


@RestController
public class ScheduleController {
	@Autowired
	SportsService service;
	
	
	
	@RequestMapping(value="/saveDay",  method=RequestMethod.POST)
	Day save(@RequestBody Day d) {
		
		return service.save(d);
	}
	@RequestMapping(value="/findGames", method=RequestMethod.GET)
	Day findByDayName(String name) {
		return service.findByDayName(name);
	}
	@RequestMapping(value="/findDay", method=RequestMethod.GET)
	List<Day> findByGameName(String name){
		return service.findByGameName(name);
	}
}
