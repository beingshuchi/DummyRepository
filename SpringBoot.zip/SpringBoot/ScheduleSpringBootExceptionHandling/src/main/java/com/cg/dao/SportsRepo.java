package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.bean.Day;
@Repository
public interface SportsRepo extends JpaRepository<Day,Integer>{
@Query("Select d from Day d WHERE d.name=:n")
Day findByDayName(@Param(value="n")String name);
@Query("Select d from Day d INNER JOIN d.games g WHERE g.name = :g ")
List<Day> findByGameName(@Param(value="g")String name);

}