package com.cg.fs.exception;

public class EmployeeException extends Exception{

	public EmployeeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
}
