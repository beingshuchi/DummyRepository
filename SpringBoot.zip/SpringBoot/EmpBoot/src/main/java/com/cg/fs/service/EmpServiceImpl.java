package com.cg.fs.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fs.bean.Employee;
import com.cg.fs.exception.EmployeeException;
import com.cg.fs.repo.IEmpRepo;

@Service(value="service")
public class EmpServiceImpl implements IEmpService{
	@Autowired
	IEmpRepo repo;

	@Override
	@Transactional
	public Employee save(Employee emp) {
		// TODO Auto-generated method stub
		repo.save(emp);
		return emp;
	}

	@Override
	@Transactional
	public Employee update(String id) {
		// TODO Auto-generated method stub
		Employee emp=repo.find(id);
		emp.setSalary(emp.getSalary().add(new BigDecimal(500)));
		repo.save(emp);
		return emp;
	}
	@Override
	@Transactional
	public Employee updateName(String id,String name) {
		// TODO Auto-generated method stub
		Employee emp=repo.find(id);
		emp.setName(name);;
		repo.save(emp);
		return emp;
	}

	@Override
	@Transactional
	public boolean delete(String id) {
		// TODO Auto-generated method stub
		boolean status=false;
		Employee emp=repo.find(id);
		if(emp!=null) {
			repo.deleteEmp(id);
				status=true;
			
			
		}
		
		return status;
	}

	@Override
	public List<Employee> viewAll() {
		// TODO Auto-generated method stub
		List<Employee> empList=repo.findAll();
		return empList;
	}

	@Override
	public Employee findById(String id) throws EmployeeException{
		// TODO Auto-generated method stub
		Employee emp= repo.find(id);
		
			if(null!=emp) {
				return emp;
			}
			else {
				throw new EmployeeException(" could not find the employee with the id "+id);
			}
		
	}
	
}
