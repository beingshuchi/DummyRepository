package com.cg.fs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.cg.fs.bean.Employee;
import com.cg.fs.exception.EmployeeException;
import com.cg.fs.service.IEmpService;

@RestController
@EnableWebMvc
public class Controller {
@Autowired
IEmpService service;

@RequestMapping(value="/save",  method=RequestMethod.POST)
Employee save(@RequestBody Employee emp) {
	service.save(emp);
	return emp;
}


@PutMapping(value="/update")
Employee update(String id) {
	Employee emp=service.update(id);
	return emp;
}

@PutMapping(value="/updateName/{id}")
Employee updateName(@PathVariable String id,@RequestBody String name) {
	Employee emp=service.updateName(id, name);
	return emp;
}

@RequestMapping(value="/delete/{id}",  method=RequestMethod.DELETE)
boolean delete(@PathVariable(value="id")String id) {
	boolean status=service.delete(id);
	return status;
}
@GetMapping(value="/viewAll")
public List<Employee> viewAll() {
	// TODO Auto-generated method stub
	List<Employee> empList=service.viewAll();
	return empList;
}
@RequestMapping(value="/find", method=RequestMethod.GET)
public Employee findById(String id) throws EmployeeException {
	// TODO Auto-generated method stub
	Employee emp;
	
		try {
			emp = service.findById(id);
			return emp;
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			
				throw new EmployeeException(e.getMessage());
			
		}
		
	
}
}
