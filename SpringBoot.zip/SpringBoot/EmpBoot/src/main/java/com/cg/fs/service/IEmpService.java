package com.cg.fs.service;

import java.util.List;

import com.cg.fs.bean.Employee;
import com.cg.fs.exception.EmployeeException;

public interface IEmpService {
	Employee save(Employee emp);
	Employee update(String id);
	boolean delete(String id);
	List<Employee> viewAll();
	Employee findById(String id) throws EmployeeException;
	Employee updateName(String id,String name);
}
