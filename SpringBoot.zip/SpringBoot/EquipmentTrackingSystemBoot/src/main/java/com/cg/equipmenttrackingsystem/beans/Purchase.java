package com.cg.equipmenttrackingsystem.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
@Entity
public class Purchase {
	@Id
	private String id; //primary key
	@OneToOne
	private User user;
	@OneToOne
	private Equipment equipment;
	@OneToOne
	private CostCentre costCentre;
	public Purchase() {
	
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Equipment getEquipment() {
		return equipment;
	}
	public void setEquipment(Equipment equipment) {
		this.equipment = equipment;
	}
	public CostCentre getCostCentre() {
		return costCentre;
	}
	public void setCostCentre(CostCentre costCentre) {
		this.costCentre = costCentre;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", user=" + user + ", equipment=" + equipment + ", costCentre=" + costCentre + "]";
	}
	
	
	
}
