package com.cg.equipmenttrackingsystem.stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class QueryFeatureStepDefinition {
	
	@Given("^user is on search page$")
	public void user_is_on_search_page() throws Throwable {
	    
	}

	@When("^user checks the equipment tag$")
	public void user_checks_the_equipment_tag() throws Throwable {
	    
	}

	@When("^types the equpment tag$")
	public void types_the_equpment_tag() throws Throwable {
	   
	}

	@Then("^system manipulates the barcode equipment tag for storage consistency$")
	public void system_manipulates_the_barcode_equipment_tag_for_storage_consistency() throws Throwable {
	   
	}

	@Then("^the tracking details for the equipment is displayed$")
	public void the_tracking_details_for_the_equipment_is_displayed() throws Throwable {
	   
	}

	@When("^user checks sequence number$")
	public void user_checks_sequence_number() throws Throwable {
	    
	}

	@When("^types the sequence number$")
	public void types_the_sequence_number() throws Throwable {
	   
	}

	@Then("^system manipulates the sequence number for storage consistency$")
	public void system_manipulates_the_sequence_number_for_storage_consistency() throws Throwable {
	   
	}

	@When("^user checks machineId$")
	public void user_checks_machineId() throws Throwable {
	    
	}

	@When("^types the MachineId$")
	public void types_the_MachineId() throws Throwable {
	   
	}

	@When("^user checks userId$")
	public void user_checks_userId() throws Throwable {
	 
	}

	@When("^types the userId$")
	public void types_the_userId() throws Throwable {
	    
	}

	@When("^user checks location$")
	public void user_checks_location() throws Throwable {
	   
	}

	@When("^types the location from the list$")
	public void types_the_location_from_the_list() throws Throwable {
	   
	}

	@Then("^all the equiments present in that location is displayed$")
	public void all_the_equiments_present_in_that_location_is_displayed() throws Throwable {
	    
	}
}
