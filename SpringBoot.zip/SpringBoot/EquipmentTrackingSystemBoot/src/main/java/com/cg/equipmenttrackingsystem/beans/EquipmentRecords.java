package com.cg.equipmenttrackingsystem.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
@Entity
public class EquipmentRecords {
	@Id
	private String equipmentTag;//primary key
	//private Tracking track;
	@OneToOne
	private Purchase purchase;
	public EquipmentRecords() {
		
	}
	public String getEquipmentTag() {
		return equipmentTag;
	}
	public void setEquipmentTag(String equipmentTag) {
		this.equipmentTag = equipmentTag;
	}
	public Purchase getPurchase() {
		return purchase;
	}
	public void setPurchase(Purchase purchase) {
		this.purchase = purchase;
	}
	@Override
	public String toString() {
		return "EquipmentRecords [equipmentTag=" + equipmentTag + ", purchase=" + purchase + "]";
	}
	
	
	
	
}
