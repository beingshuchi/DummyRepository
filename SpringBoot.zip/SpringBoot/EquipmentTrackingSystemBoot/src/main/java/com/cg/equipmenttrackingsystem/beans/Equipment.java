package com.cg.equipmenttrackingsystem.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
@Entity
public class Equipment {
	@Id
	private String machineId;//primary key
	private String name;
	@OneToOne
	private Status status;
	@OneToOne
	private EquipmentType type;
	public Equipment() {
		
	}
	public String getMachineId() {
		return machineId;
	}
	public void setMachineId(String machineId) {
		this.machineId = machineId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public EquipmentType getType() {
		return type;
	}
	public void setType(EquipmentType type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "Equipment [machineId=" + machineId + ", name=" + name + ", status=" + status + ", type=" + type + "]";
	}
	
	
}
