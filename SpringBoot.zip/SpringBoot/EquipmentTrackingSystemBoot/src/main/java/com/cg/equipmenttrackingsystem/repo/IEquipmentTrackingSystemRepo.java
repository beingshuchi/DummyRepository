package com.cg.equipmenttrackingsystem.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.equipmenttrackingsystem.beans.EquipmentRecords;
import com.cg.equipmenttrackingsystem.beans.Tracking;

@Repository
public interface IEquipmentTrackingSystemRepo extends JpaRepository<Tracking, String>{
	@Query("SELECT t.equipmentRecords FROM Tracking t INNER JOIN t.EquipmentRecords er WHERE er.equipmentTag=:id")
	EquipmentRecords findBy(@Param(value="id")String equipmentTag);
	@Query("SELECT er FROM EquipmentRecords er INNER JOIN er.Purchase p  INNER JOIN p.Equipment e INNER JOIN e.EquipentType et WHERE et.seqNo=:id")
	EquipmentRecords findBySeqNo(@Param(value="id") String seqNo);
	@Query("SELECT er FROM EquipmentRecords er INNER JOIN er.Purchase p  INNER JOIN p.Equipment e WHERE e.machineId=:id")
	EquipmentRecords findByMachineId(@Param(value="id") String machineId);
	@Query("SELECT er FROM EquipmentRecords er INNER JOIN er.Purchase p  INNER JOIN p.User u WHERE u.userId=:id")
	EquipmentRecords findByUserId(@Param(value="id") String userId);
	@Query("SELECT t.equipmentRecords FROM Tracking t INNER JOIN t.Location l WHERE l.name=:location")
	List<EquipmentRecords> findByLocation(@Param(value="location") String location);
}
