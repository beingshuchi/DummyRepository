package com.cg.equipmenttrackingsystem.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
@Entity
public class Tracking {
	@Id
	private String trackingId;//primary key
	@OneToOne
	private EquipmentRecords equipmentRecords;
	@OneToOne
	private Department dept;
	@OneToMany(fetch=FetchType.LAZY)
	private List<Location> locations;
	private String Comment;
	public Tracking() {
		
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	public List<Location> getLocations() {
		return locations;
	}
	public void setLocations(List<Location> locations) {
		this.locations = locations;
	}
	public String getComment() {
		return Comment;
	}
	public void setComment(String comment) {
		Comment = comment;
	}
	public EquipmentRecords getEquipmentRecords() {
		return equipmentRecords;
	}
	public void setEquipmentRecords(EquipmentRecords equipmentRecords) {
		this.equipmentRecords = equipmentRecords;
	}
	@Override
	public String toString() {
		return "Tracking [trackingId=" + trackingId + ", equipmentRecords=" + equipmentRecords + ", dept=" + dept
				+ ", locations=" + locations + ", Comment=" + Comment + "]";
	}
	
	
	
	
	
}
