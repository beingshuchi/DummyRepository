package com.cg.equipmenttrackingsystem.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
@Entity
public class EquipmentType {
	@Id
	private String seqNo;//primary key
	private String typeName;
	public EquipmentType() {
		
	}
	public String getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	@Override
	public String toString() {
		return "EquipmentType [seqNo=" + seqNo + ", typeName=" + typeName + "]";
	}
	
}
