package com.cg.equipmenttrackingsystem.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.equipmenttrackingsystem.beans.EquipmentRecords;
import com.cg.equipmenttrackingsystem.beans.Tracking;
import com.cg.equipmenttrackingsystem.repo.IEquipmentTrackingSystemRepo;

@Service(value="service")
public class EquipmentTrackingSystemServiceImple implements IEquipmentTrackingSystemService {
	@Autowired
	private IEquipmentTrackingSystemRepo repo;

	@Override
	public EquipmentRecords findByEquipmentTag(String equipmentTag) {
		// TODO Auto-generated method stub
		EquipmentRecords rec= repo.findBy(equipmentTag);
		return rec;
	}

	@Override
	public EquipmentRecords findByMachineId(String machineId) {
		// TODO Auto-generated method stub
		EquipmentRecords erec=repo.findByMachineId(machineId);
		return erec;
	}

	@Override
	public EquipmentRecords findBySeqNo(String seqNo) {
		// TODO Auto-generated method stub
		EquipmentRecords erec=repo.findBySeqNo(seqNo);
		return erec;
	}

	@Override
	public EquipmentRecords findByUserId(String userId) {
		EquipmentRecords erec=repo.findByUserId(userId);
		return erec;
	}

	@Override
	public List<EquipmentRecords> findByLocation(String location) {
		// TODO Auto-generated method stub
		return repo.findByLocation(location);
	}

	@Override
	@Transactional
	public EquipmentRecords save(Tracking t) {
		// TODO Auto-generated method stub
		repo.save(t);
		return t.getEquipmentRecords();
	}
	
}
