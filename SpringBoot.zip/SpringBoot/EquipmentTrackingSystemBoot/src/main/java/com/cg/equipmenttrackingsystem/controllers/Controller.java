package com.cg.equipmenttrackingsystem.controllers;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.cg.equipmenttrackingsystem.beans.EquipmentRecords;

import com.cg.equipmenttrackingsystem.beans.Tracking;

import com.cg.equipmenttrackingsystem.service.IEquipmentTrackingSystemService;

@RestController
public class Controller {
	@Autowired
	IEquipmentTrackingSystemService service;
	
	@RequestMapping(value="/save",  method=RequestMethod.POST)
	public EquipmentRecords save(@RequestBody Tracking t) {
		/*EquipmentRecords er=new EquipmentRecords();*/
		/*er.setEquipmentTag("barcode00000000001");
		Purchase purchase = new Purchase();
		purchase.setId("purchase0000000001");
		User user= new User();
		user.setId("user00000001");
		user.setName("Shivani");
		purchase.setUser(user);
		CostCentre cc= new CostCentre();
		cc.setId("cc000000001");
		cc.setName("PayTM");
		CostCentre costCentre= new CostCentre();
		costCentre.setId("cc000000002");
		costCentre.setName("Paypal");
		CostCentre costC= new CostCentre();
		costC.setId("cc000000003");
		costC.setName("PhonePe");
		purchase.setCostCentre(costCentre);
		Equipment e= new Equipment();
		e.setMachineId("e000000001");
		e.setName("Iphone");
		Status status= new Status();
		status.setId("01");
		status.setName("In Use");
		Status status1= new Status();
		status1.setId("02");
		status1.setName("In stock");
		e.setStatus(status);
		EquipmentType type= new EquipmentType();
		type.setSeqNo("seq00000001");
		type.setTypeName("Mobile");
		EquipmentType type1= new EquipmentType();
		type1.setSeqNo("seq00000002");
		type1.setTypeName("Laptop");
		e.setType(type);
		Equipment equipment= new Equipment();
		equipment.setMachineId("e000000002");
		equipment.setName("Samsung");
		equipment.setStatus(status);
		equipment.setType(type);
		purchase.setEquipment(equipment);
		er.setPurchase(purchase);
		Tracking track= new Tracking();
		track.setTrackingId("track00000001");
		track.setEquipmentRecords(er);
		Department d1= new Department();
		d1.setDeptId("de00000001");
		d1.setDeptName("Inventory personnel");
		Department d2= new Department();
		d2.setDeptId("de00000002");
		d2.setDeptName("equipment auditors");
		Department d3= new Department();
		d3.setDeptId("de00000003");
		d3.setDeptName("service personnel");
		Department d4= new Department();
		d4.setDeptId("de00000004");
		d4.setDeptName("maintenance personal");
		Department dept= new Department();
		dept.setDeptId("de00000005");
		dept.setDeptName("Equipment Tracking personnel");
		track.setDept(dept);
		Location l1= new Location();
		l1.setLocationId("loc000001");
		l1.setName("Mumbai");
		Location l2= new Location();
		l2.setLocationId("loc000002");
		l1.setName("Delhi");
		Location l3= new Location();
		l3.setLocationId("loc000003");
		l3.setName("Pune");
		Location l4= new Location();
		l4.setLocationId("loc000004");
		l4.setName("Bangalore");
		Location l5= new Location();
		l5.setLocationId("loc000005");
		l5.setName("Chennai");
		Location l6= new Location();
		l6.setLocationId("loc000006");
		l6.setName("Hyderabad");
		List<Location> locations=new ArrayList<Location>();
		locations.add(l1);
		locations.add(l2);
		locations.add(l3);
		locations.add(l4);
		locations.add(l5);
		locations.add(l6);
		track.setLocations(locations);
		track.setComment("Its in good condition");
		EquipmentRecords ers=service.save(track);
		System.out.println(track.getComment());*/
		
		return service.save(t);
	}
}
