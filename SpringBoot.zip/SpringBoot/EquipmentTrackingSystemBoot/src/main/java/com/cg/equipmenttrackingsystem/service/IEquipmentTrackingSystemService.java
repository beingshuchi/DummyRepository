package com.cg.equipmenttrackingsystem.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cg.equipmenttrackingsystem.beans.EquipmentRecords;
import com.cg.equipmenttrackingsystem.beans.Tracking;

public interface IEquipmentTrackingSystemService {
	EquipmentRecords findByEquipmentTag(String equipmentTag);
	EquipmentRecords findBySeqNo(String seqNo);
	EquipmentRecords findByMachineId(String machineId);
	EquipmentRecords findByUserId(String userId);
	List<EquipmentRecords> findByLocation(String location);
	EquipmentRecords save(Tracking t);
}
