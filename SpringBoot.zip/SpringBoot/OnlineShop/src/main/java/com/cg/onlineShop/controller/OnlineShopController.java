package com.cg.onlineShop.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlineShop.bean.Product;
import com.cg.onlineShop.exception.OnlineShopException;
import com.cg.onlineShop.service.IOnlineShopService;

@RestController
public class OnlineShopController {
	@Autowired
	private IOnlineShopService service;
	@RequestMapping(method=RequestMethod.GET,value= {"/sayHello"},produces={"application/text"})
	public ResponseEntity<String> getHelloMessage(){
	return new ResponseEntity<String>("Hello World From RestFulWebService",HttpStatus.OK);
	}

	
	@RequestMapping(value="/save",method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	ResponseEntity<Product> addProuct(@ModelAttribute Product product) throws OnlineShopException {
		
		return new ResponseEntity<Product>(service.addProduct(product), HttpStatus.OK);
	}
	@RequestMapping(value="/get/{code}",method=RequestMethod.GET)
	ResponseEntity<Product>  getProductDetails(@PathVariable(value="code") String productCode) throws OnlineShopException {
		
		return new ResponseEntity<Product>(service.findProduct(productCode), HttpStatus.OK);
	}
	
	@RequestMapping(value="/getAll",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<List<Product>> getAllProductDetails() throws OnlineShopException {
		return new ResponseEntity<List<Product>>(service.viewAll(), HttpStatus.OK);
	}
	
	
	
}
