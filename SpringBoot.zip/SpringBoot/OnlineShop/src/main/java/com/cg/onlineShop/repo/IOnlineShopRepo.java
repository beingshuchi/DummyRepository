package com.cg.onlineShop.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.onlineShop.bean.Product;

@Repository
public interface IOnlineShopRepo extends JpaRepository<Product, String> {

}
