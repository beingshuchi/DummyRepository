package com.cg.onlineShop.exception;

public class OnlineShopException extends Exception {

	public OnlineShopException() {
		
	}

	public OnlineShopException(String arg0) {
		super(arg0);
		
	}

}
