package com.cg.onlineShop.service;

import java.util.List;

import com.cg.onlineShop.bean.Product;
import com.cg.onlineShop.exception.OnlineShopException;

public interface IOnlineShopService {
	Product addProduct(Product product) throws OnlineShopException;
	Product findProduct(String productCode) throws OnlineShopException;
	List<Product> viewAll() throws OnlineShopException;
}
