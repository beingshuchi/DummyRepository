package com.cg.onlineShop.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlineShop.bean.Product;
import com.cg.onlineShop.exception.OnlineShopException;
import com.cg.onlineShop.repo.IOnlineShopRepo;

@Service(value="service")
public class OnlineShopServiceImpl implements IOnlineShopService{
	@Autowired
	private IOnlineShopRepo repo;
	
	@Override
	@Transactional
	public Product addProduct(Product product) throws OnlineShopException {
		// TODO Auto-generated method stub
		Product p=new Product();
		p.setProductCode(product.getProductCode());
		p.setName(product.getName());
		p.setPrice(product.getPrice());
		p.setDescription(product.getDescription());
		p.setManufacturingDate(product.getManufacturingDate());
		repo.save(p);
		return p;
	}

	@Override
	public Product findProduct(String productCode) throws OnlineShopException {
		// TODO Auto-generated method stub
		Product product=repo.getOne(productCode);
		if(product!=null) {
			return product;
		}else {
			throw new OnlineShopException("Could not find the employee");
		}
	}

	@Override
	public List<Product> viewAll() throws OnlineShopException {
		// TODO Auto-generated method stub
		List<Product> products= repo.findAll();
		return products;
	}
	
}
