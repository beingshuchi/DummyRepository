import { Component } from '@angular/core';

//meto data
//component-decorator
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'shuchi';
}
