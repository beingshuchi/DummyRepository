import React from 'react';
import TreatySearch from './TreatySearch';
import TreatyTable from './TreatyTable';
export default class Treaty extends React.Component{
    render(){
        return(
        <div className="p-col-12 p-md-1 p-lg-12">
      <h1><u>Treaties</u></h1>
      <TreatySearch />
      
      <div id="table"  className="p-col-12 p-md-3 p-lg-12"><TreatyTable /></div>
  </div>
        );
    }
}