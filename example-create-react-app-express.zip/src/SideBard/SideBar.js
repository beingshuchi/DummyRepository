import React from 'react';
import {Sidebar} from 'primereact/components/sidebar/Sidebar';
export default class SideBar extends React.Component{
  
    constructor() {
        super();
        this.state = {
            visibleLeft: false
        };
    }

    render(){
        return(
            <div>
            <Sidebar visible={true} baseZIndex={1000000} onHide={() => this.setState({visibleLeft: false})}>
                        <span><b>Life</b></span><br/>
                        <span><b>Claim</b></span><br/>
                        <span><b>Policy</b></span><br/>
                        <span><b>Treaty and Reinsurance plan</b></span>
                       
                    </Sidebar>
                   
                    </div>
        );
    }
}