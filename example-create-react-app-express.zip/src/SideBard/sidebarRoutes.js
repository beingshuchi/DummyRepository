import React from "react";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import {Treaty} from "../Treaties/Treaty";
const Life = () => <h2>Life</h2>;
const Claim = () => <h2>Claim</h2>;
const Policy = () => <h2>Policy</h2>;
const TreatyAndReinsurancePlan =()=><h2>Treaty and Reinsurance plan</h2>

const sidebarRoutes = () => (
  <Router>
    <div>
      <nav>
        <ul>
          <li>
            <Link to="/life">Life</Link>
          </li>
          <li>
            <Link to="/claim">Claim</Link>
          </li>
          <li>
            <Link to="/Policy">Policy</Link>
          </li>
          <li>
            <Link to="/Treaty">TreatyAndReinsurancePlan</Link>
          </li>
        </ul>
      </nav>

      <Route path="/" exact component={Index} />
      <Route path="/Treaty" component={Treaty} />
    </div>
  </Router>
);

export default sidebarRoutes;