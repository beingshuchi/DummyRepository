import React, { Component } from 'react';
import './App.css';
import {InputBox} from './InputBox';
import {dataService} from './dataService';
import {RadioButton} from './RadioButton';
import {DropDown} from './DropDown';
import { CheckedBox } from './CheckedBox';
import { Submit } from './Submit';
import { PasswordBox } from './PasswordBox';

class App extends Component {
  constructor(props){
    super(props);
    this.state={items:[]};
    this.dataService= new dataService();
  }
  /*componentWillMount(){
    fetch("components/form.json").then(response=>response.json).then(({results: items})=>{this.setState({items})})
  }*/
  componentDidMount(){
    this.dataService.getComponentData().then(item=>this.setState({items:item}));
  }
  getComponent(item,index){
    switch(item.properties.type){
      case "text":
      return <InputBox className="input" key={index} lable={item.lable} type={item.properties.type} placeholder={item.properties.description} pattern={item.properties.pattern} maxLength={item.properties.maxLength} minLength={item.properties.minLength}/>
      
      case "password":
      return <PasswordBox key={index} lable={item.lable} placeholder={item.properties.description}  pattern={item.properties.pattern} maxLength={item.properties.maxLength} minLength={item.properties.minLength}/>
      
      case "dropDown":
      return <DropDown key={index} lable={item.lable} type={item.properties.type} arrayData={item.properties.enum}/>
      
      case "radio":
      return <RadioButton key={index} type='radio' lable={item.lable} arrayData={item.properties.anyOf.enum}/>
      
      case "checkBox":
      return <CheckedBox key={index} lable={item.lable} type={item.properties.type} arrayData={item.properties.items.enum}/>
      
      case "submit":
      return <Submit key={index} type={item.properties.type} title={item.properties.title}/>
      
      default:
      break;
    }
  }
  render() {
    let items=this.state.items;
    const dynamicComponents= items.map((item,index)=><div>
      
          {
            this.getComponent(item,index)
            /*item.properties.type==='text'?<InputBox lable={item.lable} type={item.properties.type} placeholder={item.properties.description} pattern={item.properties.pattern} maxLength={item.properties.maxLength} minLength={item.properties.minLength}/>:
            item.properties.type==='password'?<InputBox lable={item.lable} type={item.properties.type} placeholder={item.properties.description}  pattern={item.properties.pattern} maxLength={item.properties.maxLength} minLength={item.properties.minLength}/>:
            item.properties.type==='dropDown'?<DropDown lable={item.lable} type={item.properties.type} arrayData={item.properties.enum}/>:
            item.properties.type==='radio'?
            <RadioButton type='radio' lable={item.lable} arrayData={item.properties.anyOf.enum}/>:
            item.properties.type==='checkBox'?<CheckBox lable={item.lable} type={item.properties.type} arrayData={item.properties.items.enum}/>:
            <Submit type={item.properties.type} title={item.properties.title}/>*/
          }
      
    </div>)
    
    return (
      <div className="App">
      <h2>React Form</h2>
      <form autoComplete="off"> 
        
         
      {
       dynamicComponents
      }
      
      
      </form>
      </div>
    );
  }
}

export default App;
