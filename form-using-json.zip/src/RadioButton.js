import React from 'react';
import {InputText} from 'primereact/components/inputtext/InputText'
export class RadioButton extends React.Component {
    
    constructor() {
        super();
        this.state = {
            value: null
        };
    }
    
    render(){
        const options= this.props.arrayData.map((arrayData,index) => (
        /*<select>
                    <option label={this.props.lable} value={arrayData.value}>{arrayData.name}</option>
                </select>*/
                <span key={index}>
                 <InputText className="p-inputtext" value={this.state.value1} onChange={(e) => this.setState({value1: e.target.value})} type={this.props.type} name={this.props.lable} value={arrayData.value}/>{arrayData.name}
                
                {/* <RadioButton inputId={index} name={arrayData.name} value={arrayData.value} onChange={(e) => this.setState({value1: e.value})} checked={this.state.value === arrayData.value} /> */}
                </span> 
        ));
        return(
            <div>
              {this.props.lable} :  {options}
            </div>
        );
    }
}