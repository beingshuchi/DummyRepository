import React from 'react';
import {InputText} from 'primereact/components/inputtext/InputText'
import {CheckBox, Checkbox} from 'primereact/components/checkbox/Checkbox';
export class CheckedBox extends React.Component {
    
    constructor() {
        super();
        this.state = {
            checked:false,
            value: []
        };
        this.onLangChange = this.onLangChange.bind(this);
    }
    onLangChange(e) {
        let selectedLang = [...this.state.value];
        
        if(e.checked)
            selectedLang.push(e.value);
        else
            selectedLang.splice(selectedLang.indexOf(e.value), 1);

        this.setState({value: selectedLang});
    }

    
    
    render(){
        const options= this.props.arrayData.map((item,index) => (
        <span key={index}>
            <Checkbox className="p-checkbox-icon p-c pi pi-check" inputId={index} value={item} onChange={this.onLangChange} checked={this.state.value.indexOf(item) !== -1}></Checkbox> 
      {/*<InputText className="radio p-inputtext" onChange={/*(e) => this.setState({value1: e.target.value})this.onLangChange} type={this.props.type} name={item} value={item}/>  */}
        <label htmlFor={index} className="p-checkbox-label">{item}</label> <span>  </span>
       </span>
      ));
        return(
            <div>
              {this.props.lable} :  {options}
            
            </div>
        );
    }
}