import React from 'react';
import {Button} from  'primereact/components/button/Button'

export class Submit extends React.Component {
   
    
    render(){
     
        return(
            <div>
               
              {/* <button type={this.props.type}>{this.props.title}</button> */}
              <Button className="p-button-raised p-button-rounded" label={this.props.title}/>
              
            </div>
        );
    }
}