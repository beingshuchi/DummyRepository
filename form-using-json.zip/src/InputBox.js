import React from 'react';
import {InputText} from 'primereact/components/inputtext/InputText'
export class InputBox extends React.Component{

    constructor() {
        super();
        this.state = {
            value: null
        };
    }
    
    render(){
        return(
            <div>
                {this.props.lable} :<span> </span> <InputText autoComplete="off" className="p-inputtext" required value={this.state.value1} onChange={(e) => this.setState({value1: e.target.value})} type={this.props.type} maxLength={this.props.maxLength} placeholder={this.props.placeholder} minLength={this.props.minLength} keyfilter={this.props.pattern}/>
            </div>
        );
    }
}