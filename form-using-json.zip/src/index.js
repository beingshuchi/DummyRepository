import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import 'primereact/components/password/Password.css';
import 'primereact/components/inputtext/InputText.css';
import 'primereact/components/checkbox/Checkbox.css';
import 'primereact/components/button/Button.css'
import * as serviceWorker from './serviceWorker';

ReactDOM.render(<App />, document.getElementById('root'));

serviceWorker.unregister();
