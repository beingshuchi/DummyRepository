import React from 'react';

export default class Main extends React.Component{
    render(){
      
    return myjson.forEach(singleObject => {
        
      });
    }
}