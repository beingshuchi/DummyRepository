import React from 'react';

export class DropDown extends React.Component {
    
    render(){
        const options= this.props.arrayData.map((arrayData,index) => (
        
        <option key={index} value={arrayData}>{arrayData}</option>
       
      ));
        return(
            <div>
              {this.props.lable} : <span> </span><select> {options} </select>
            </div>
        );
    }
}