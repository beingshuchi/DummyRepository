import React from 'react';
import {Password} from 'primereact/components/password/Password'
export class PasswordBox extends React.Component{

    constructor() {
        super();
        this.state = {
            value:''
        };
    }
    
    render(){
        return(
            <div>
                {this.props.lable} : <span> </span><Password autoComplete="off" promptLabel="" weakLabel="" mediumLabel="" strongLabel="" required value={this.state.value} onChange={(e) => this.setState({value: e.target.value})}  placeholder={this.props.placeholder}  />
            </div>
        );
    }
}