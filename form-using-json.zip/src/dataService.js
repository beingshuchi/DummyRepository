import axios from 'axios';

export class dataService {
    getComponentData(){
        return axios.get("components/form.json").then(res => res.data.items);
        //.then(res => <ITreaties[]>res.data)
        //.then(data => { return data; });
                
    }

    
}
