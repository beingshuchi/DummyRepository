import React from 'react';
import PropTypes from 'prop-types'

export default class Home extends React.Component{
    constructor(props){
        super(props);
        this.state={
            age: props.initialAge,
            status: 0,
            homeLink: props.initialLinkName
        } 
        setTimeout(()=>{this.setState({status: 1})},3000);
    }

    onMakeOlder(){
        this.setState(
            {
                age: this.state.age+3
            }
        );
       // this.age +=3;
       // console.log(this.age);
    }
    onHandleChange(e){
        this.setState({
            homeLink: e.target.value
        });
    }

    onChangeLinkName(){
        this.props.changeLink(this.state.homeLink);
    }
    render(){
        //var text="Something!!";
        return(
            
            <div>
                <p>
                in the new component !
                </p>
                <p>Your nam is {this.props.name}, your age is {this.state.age}</p>
                <p>Status: {this.state.status}</p>
                <hr/>
                <button className="btn btn-primary" onClick={()=>this.onMakeOlder()}>Make me older!!</button>
                <hr/>
                <button onClick={this.props.greet} className="btn btn-primary">Greet</button>
                <hr/>
                <input type="text" value={this.state.homeLink} onChange={(event)=> this.onHandleChange(event)}/>
                <button onClick={this.onChangeLinkName.bind(this)} className="btn btn-primary">Change Header</button>
                 {/*<p>User Object => Name: {this.props.name}</p>
                <div>
                    <h4>Hobbies</h4>
                    <ul>
                        
                            {this.props.user.hobbies.map((hobby,i) =><li key={i}>{hobby}</li>)}
                        
                    </ul>
                </div>
                <hr/>
                {this.props.children} */}
            </div>
        );
    }
}

 Home.propTypes={
    name: PropTypes.string,
    initialAge: PropTypes.number,
    greet: PropTypes.func,
    initialLinkName: PropTypes.string
   //user: PropTypes.object,
   //children: PropTypes.element.isRequired
 };