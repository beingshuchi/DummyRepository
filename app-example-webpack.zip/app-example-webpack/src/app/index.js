import React from "react";
import ReactDOM from "react-dom";
import {Header} from "./component/Header";
import Home from "./component/Home";

class App extends React.Component{
    constructor(){
        super();
        this.state={
            homeLink: "Home"
        }
    }

    onGreet(){
        alert("Hello");
    }

    onChangeLinkName(newName){
        //since we have used this we need to bind!!
        this.setState({
            homeLink: newName
        });
    }
    render(){
        // var user={
        //     name:"Ana",
        //     hobbies: ["sports","reading"]
        // }
        return(
            <div className="container">
            <div className="row">
            <div className=".col-xs-10.col-xs-offset-1 ">
            <Header homeLink={this.state.homeLink}/>
            </div>
            </div>

            <div className="row">
            <div className=".col-xs-10.col-xs-offset-1 ">
            {/* <Home name={"Max"} age={34} user={user}>
            <p>This is a paragraph</p>
            </Home> */}
             <Home name={"Max"} initialAge={34} greet={this.onGreet}
              changeLink={this.onChangeLinkName.bind(this)}
              initialLinkName={this.state.homeLink}/>
            </div>
            </div>
            </div>
        );
    }
}
ReactDOM.render(<App/>,window.document.getElementById("app"));