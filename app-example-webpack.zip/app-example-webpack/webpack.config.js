var path=require('path');

var DIST_DIR = path.resolve(__dirname,"dist");//copy everything into dist folder
//nothing is created but will be created automatically

var SRC_DIR = path.resolve(__dirname,"src");//to be copied from

var config={
    entry: SRC_DIR+"/app/index.js",
    output: {
        path: DIST_DIR+"/app",
        filename: "bundle.js",
        publicPath: "/app/" //where the actuall app begins with
    },
    module:{
        rules: [
            {
                test: /\.js?/,
                include: SRC_DIR,
                loader: "babel-loader",
                query: {
                    presets:["react","es2015","stage-2"]
                }
            }]
    }
};

module.exports = config;