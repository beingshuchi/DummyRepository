import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `
  <h2 *ngIf="false">
  Shuchita
  </h2>
  <hr>
  <h2 *ngIf="displayName; else elseBlock">
  Shuchita
  </h2>
  <ng-template #elseBlock>
  <h2>
  Name is hidden
  </h2>
  </ng-template>

  <hr>
<div *ngIf="displayName; then thenBlock; else elseBlock2"></div>
  <ng-template #thenBlock>
  <h2>
  Shuchita
  </h2>
  </ng-template>

  <ng-template #elseBlock2>
  <h2 >
 Hidden
  </h2>
  </ng-template>
  <hr>
  <h2>Hello {{name}}</h2>
  <button (click)="fireEvent()">Send Event</button>
<hr>
  <div class="container" [ngSwitch]="color">
 <div [style.color]="color" *ngSwitchCase="'red'"> You chose red</div>
 <div [style.color]="color" *ngSwitchCase="'blue'"> You chose blue</div>
 <div [style.color]="color" *ngSwitchCase="'green'"> You chose green</div>
 <div *ngSwitchDefault> Pick again</div>
  </div>

<hr>
<div class="container" *ngFor="let c of colors; index as i; first as f; last as l; odd as o;even as e;">
<h2 [style.color]=c>{{i}} {{c}} {{f}}  {{l}}  {{o}} {{e}}</h2>
 </div>
 <hr>
 <h2>{{name1}}</h2>
 
 <h2>{{name1 | lowercase}}</h2>
 <h2>{{name1 | uppercase}}</h2>
 <h2>{{name1 | titlecase}}</h2>
 <h2>{{name1 | slice:2:6}}</h2>
 <h2>{{name1 | slice:2:6}}</h2>
 <h2>{{person| json}}</h2>

 <h2>{{5.678 | number:'1.2-3'}}</h2>
 <h2>{{5.678 | number:'3.4-5'}}</h2>
 <h2>{{5.678 | number:'3.1-2'}}</h2>

 <h2>{{0.25 | percent}}</h2>
 <h2>{{0.25| currency}}</h2>

 <h2>{{0.25| currency: 'INR'}}</h2>
 <h2>{{0.25| currency: 'GBP'}}</h2>
 <h2>{{0.25| currency: 'EUR'}}</h2>
 <h2>{{0.25| currency: 'EUR':"code"}}</h2>
 <hr>
 <h2>{{date}}</h2>
 <h2>{{date | date:'short'}}</h2>
 <h2>{{date | date:'shortDate'}}</h2>
 <h2>{{date | date:'shortTime'}}</h2>
 <h2>{{date | date:'medium'}}</h2>
 <h2>{{date | date:'mediumDate'}}</h2>
 <h2>{{date | date:'mediumTime'}}</h2>

 `,
  styles: []
})
export class TestComponent implements OnInit {
public displayName=true;
public color="blue";
public colors=["red","blue","green","yellow"];
public name1="codevolution";
public date=new Date();
public person={
  "firstName":"Joan",
  "lastName":"Lambert"
}
//@Input() public parentData;
//the input is parent data but here it is referred to as name
@Input('parentData') public name;
@Output() public childEvent= new EventEmitter();

  constructor() { }

  ngOnInit() {
  }
  fireEvent(){
    this.childEvent.emit("Hey from child");
  }
}
