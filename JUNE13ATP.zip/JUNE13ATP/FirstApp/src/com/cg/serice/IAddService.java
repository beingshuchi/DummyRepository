package com.cg.serice;

import com.cg.bean.NumberBean;

public interface IAddService {
	public Integer add(NumberBean numberBean)throws NullPointerException;

}
