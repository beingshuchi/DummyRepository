package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.NumberBean;
import com.cg.serice.IAddService;
import com.cg.service.AddService;

/**
 * Servlet implementation class AddController
 */
@WebServlet("/AddController")
public class AddController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	private IAddService service=null;
    public AddController() {
      service= new AddService();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Integer num1=Integer.parseInt(request.getParameter("num1"));
		Integer num2=Integer.parseInt(request.getParameter("num2"));
		NumberBean numberBean= new NumberBean();
		numberBean.setNum1(num1);
		numberBean.setNum2(num2);
		Integer res=service.add(numberBean);
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.print("<html>"
				+ "<head>"
				+ "<title>Add Number</title></head>"
				+ "<body>"
				+ "<h4><center> The addtition of "+num1+" and  "+num2+" is "+res+"</center></h4>"
				+ "</body>"
				+ "</html>");
		
	}

}
