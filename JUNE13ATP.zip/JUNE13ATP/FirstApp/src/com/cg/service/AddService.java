package com.cg.service;

import com.cg.bean.NumberBean;
import com.cg.serice.IAddService;

public class AddService implements IAddService {

	@Override
	public Integer add(NumberBean numberBean) throws NullPointerException {
		// TODO Auto-generated method stub
		return (numberBean.getNum1()+numberBean.getNum2());
	}

}
