package com.cg;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet2
 */
@WebServlet({ "/Servlet2", "/fromServlet1" })
public class Serflet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Serflet2() {
       
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("in servlet 2");
		Integer fromServlet1=(Integer) getServletContext().getAttribute("num");
		Integer product=fromServlet1*fromServlet1;
		response.getWriter().print("<html>"
				+ "<body><h4 style='text-align:center'>Hello<br/>"
				+ "The Product is:"+product+"</h4></body></html>");
		
		System.out.println("bye from servlet 2");
		
	}

}
