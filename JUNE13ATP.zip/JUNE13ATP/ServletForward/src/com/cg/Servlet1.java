package com.cg;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public Servlet1() {
     
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("This is servlet1");
		String uname=request.getParameter("uname");
		String pass=request.getParameter("pass");
		request.setAttribute("uname", uname);
		request.setAttribute("pass", pass);
		RequestDispatcher rd=request.getRequestDispatcher("fromServlet1");
		rd.forward(request, response);
		String res=(String) request.getAttribute("result");
		response.getWriter().print("<html>"
				+ "<body><h4>Hello<br/>"+res+"</h4></body></html>");
	}

}
