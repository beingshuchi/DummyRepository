package com.cg.bean;

public class EmployeeBean {
private Integer eid;
private String ename;
private double sal;
public Integer getEid() {
return eid;
}
public void setEid(Integer eid) {
this.eid = eid;
}
public String getEname() {
return ename;
}
public void setEname(String ename) {
this.ename = ename;
}
public double getSal() {
return sal;
}
public void setSal(double sal) {
this.sal = sal;
}
public EmployeeBean(Integer eid, String ename, double sal) {
super();
this.eid = eid;
this.ename = ename;
this.sal = sal;
}

}