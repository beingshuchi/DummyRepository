package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.EmployeeBean;

public class EmployeeService implements IEmployeeService {

	@Override
	public ArrayList<EmployeeBean> getAllEmp() {
		// TODO Auto-generated method stub
		ArrayList<EmployeeBean> list=new ArrayList<EmployeeBean>();
		list.add(new EmployeeBean(101, "viny", 132435.78));
		list.add(new EmployeeBean(102, "Jv", 657548.9));
		list.add(new EmployeeBean(103, "susmi", 23456.45));
		return list;
	}

}
