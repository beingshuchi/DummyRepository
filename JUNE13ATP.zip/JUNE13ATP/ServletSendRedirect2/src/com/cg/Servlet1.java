package com.cg;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public Servlet1() {
     
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("This is servlet1");
		Integer num=Integer.parseInt(request.getParameter("num"));
		Integer number=num+5;
		//request.getSession().setAttribute("number", number);
		//request.getSession(false).setAttribute("num",num);;
		response.sendRedirect("fromServlet1?number="+number);
		//String res=(String) request.getAttribute("result");
	
	}

}
