package com.cg.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet1Page2
 */
@WebServlet("/Servlet1Page2")
public class Servlet1Page2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet1Page2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String mobile=request.getParameter("mobile");
		response.getWriter().print("<!DOCTYPE html> <html> "
				+ "<head> <meta charset='ISO-8859-1'> <title>Page2</title>"
				+ "</head>"
				+ "<body> <form action='Servlet2Page3' method='post'>"
				+ "<input type='hidden' name='fname' value='"+fname+"'/>"
				+"<input type='hidden' name='lname' value='"+lname+"'/>"
				+"<input type='hidden' name='mobile' value='"+mobile+"'/>"
				+ "Gender<input type='text' name='gen'/><br/>"
				+ "Email<input type='text' name='email'/><br/>"
				+ "<input type='submit' value='Continue'/>"
				+ "</form></body></html>");
	}

}
