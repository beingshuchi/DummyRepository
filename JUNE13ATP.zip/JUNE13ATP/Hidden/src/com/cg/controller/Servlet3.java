package com.cg.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet3
 */
@WebServlet("/Servlet3")
public class Servlet3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String mobile=request.getParameter("mobile");
		String email=request.getParameter("email");
		String gen=request.getParameter("gen");
		String state=request.getParameter("state");
		String country=request.getParameter("country");
		response.getWriter().print("<!DOCTYPE html> <html> "
				+ "<head> <meta charset='ISO-8859-1'> <title>Page3</title>"
				+ "</head>"
				+ "<body> <form action='Servlet3' method='post'>"
				+ "First Name: "+fname+"<br/>"
				+"Last Name: "+lname+"<br/>"
				+"Mobile Num: "+mobile+"<br/>"
				+ "Gender:"+gen+"<br/>"
				+ "Email"+email+"<br/>"
				+"State:"+state+"<br/>"
				+ "Country"+country+"<br/>"
				+ "</form></body></html>");
	}

}
