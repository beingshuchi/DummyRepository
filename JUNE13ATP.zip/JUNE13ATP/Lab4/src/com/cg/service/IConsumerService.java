package com.cg.service;

import com.cg.bean.ConsumerBean;
import com.cg.exception.ConsumerException;

public interface IConsumerService{
ConsumerBean findEmpById(int id) throws ConsumerException;
}
