package com.cg.service;

import com.cg.bean.ConsumerBean;
import com.cg.dao.ConsumerDao;
import com.cg.dao.IConsumerDao;
import com.cg.exception.ConsumerException;

public class ConsumerService implements IConsumerService {
IConsumerDao dao= new ConsumerDao();
	@Override
	public ConsumerBean findEmpById(int id) throws ConsumerException {
		// TODO Auto-generated method stub
		return dao.findEmpById(id);
	}

}
