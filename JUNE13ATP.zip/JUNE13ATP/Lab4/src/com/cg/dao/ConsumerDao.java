package com.cg.dao;

import javax.persistence.EntityManager;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.bean.ConsumerBean;
import com.cg.exception.ConsumerException;

public class ConsumerDao implements IConsumerDao{

	@Override
	public ConsumerBean findEmpById(int id) throws ConsumerException {
		// TODO Auto-generated method stub
		EntityManagerFactory fact= Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=fact.createEntityManager();
		em.getTransaction().begin();
		ConsumerBean cb=em.find(ConsumerBean.class, id);
		
		if(cb!=null){
			return cb;
		}
		else{
			throw new ConsumerException("This id does not exists");
		}
	}

}
