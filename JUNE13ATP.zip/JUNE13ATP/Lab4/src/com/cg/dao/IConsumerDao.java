package com.cg.dao;

import com.cg.bean.ConsumerBean;
import com.cg.exception.ConsumerException;

public interface IConsumerDao {
	ConsumerBean findEmpById(int id) throws ConsumerException;
}
