package com.cg.exception;

@SuppressWarnings("serial")
public class ConsumerException extends Exception {

	public ConsumerException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ConsumerException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
