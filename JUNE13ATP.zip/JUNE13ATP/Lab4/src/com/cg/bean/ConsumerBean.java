package com.cg.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Cosumers")
public class ConsumerBean {
	@Id
	Integer consumer_num ;
	String consumer_name ;
	String address;
	public ConsumerBean() {
		super();
	}
	public Integer getConsumer_num() {
		return consumer_num;
	}
	public void setConsumer_num(Integer consumer_num) {
		this.consumer_num = consumer_num;
	}
	public String getConsumer_name() {
		return consumer_name;
	}
	public void setConsumer_name(String consumer_name) {
		this.consumer_name = consumer_name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	

}
