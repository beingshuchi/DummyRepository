import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IComponent } from './component';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ComponentService {
private _url:string="/assets/components/form.json";
  constructor(private http:HttpClient) { }
 public getComponents():Observable<IComponent[]>{
    return this.http.get<IComponent[]>(this._url);
  }
}
