export interface IComponent{
   data: object
}