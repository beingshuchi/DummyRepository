import { Component, OnInit, Output, EventEmitter} from '@angular/core';
import { ComponentService } from '../component.service';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
public components:any=[];
//rForm: FormGroup;
selected;

  constructor(private _componentService:ComponentService) {
    //,private fb: FormBuilder
    // this.rForm = fb.group({
    //   add: this.fb.array([]),
    // });
    // this.addData()
   }

  ngOnInit() {
    this._componentService.getComponents().subscribe(data=>this.components.push(data));
    console.log(this.components)
  }
  onChange(gender){
    this.selected =gender;
  }

  formSubmitted(value) {
    alert(value);
  }

  addData() {
  //  let formArr = this.rForm.controls.add as FormArray;
    // this.data.forEach(x => {
    //   formArr.push(this.fb.group({
    //     name: x.name,
    //    username: x.username,
    //     email: x.email,
    //     password: x.password,
    //     country: x.country,
    //     gender: x.gender,
    //     language: x.language
    //   }))
    // })
  }
}
