import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `
  <h2>
   Welcome {{name}}!
  </h2>
  <h2>{{2+2}}</h2>
  <h2>{{"Welcome " + name}}</h2>
  <h2>{{name.length}}</h2>
  <h2>{{name.toUpperCase()}}</h2>
  <h2>{{greetUser()}}</h2>
  <input [id]="myId" type="text" value="Shh"/>
  <hr/>
  <input bind-disabled= "isDisabled" id={{myId}} type="text" value="Shh"/>
  <h2 [class]="successClass">Code</h2>
  <h2 class="text-special" [class]="successClass">Code</h2>
  <h2 [class.text-danger]="hasError">Code</h2>

  <h2 [ngClass]="messageClasses">Coding is great!!</h2>

  <h2 [style.color]="hasError ? 'red':'green'">Style Binding</h2>

  <h2 [style.color]="highlightColor">Style Binding 2</h2>
  <h2 [ngStyle]="titleStyles">Style Binding 3</h2>

  <button (click)="onClick()">Greet</button><br><br>
 
  <button (click)="onClick2($event)">Greet 2</button><br><br>

  <button (click)="greeting='Welcome shuchi'">Greet 3</button><br><br>

  {{greeting}}

  <hr>
  <input #myInput type="text">
  <button (click)="logMessage(myInput.value)">Log</button>
  <br>
  <hr>
  <br>
  <input [(ngModel)]="name2" type="text">
  <br>
  {{name2}}
  `,
  styles: [`
  .text-success{
    color: green;
  }
  .text-danger{
    color:red;
  }
  .text-special{
    font-style: italic;
  }
  `]
})
export class TestComponent implements OnInit {
  public name="Shuchita";
  public myId= "testId";
  public successClass="text-success"
  public isDisabled=false;
  public hasError=true;
  public isSpecial=true;
  public highlightColor="orange";
  public greeting="";
  public name2="";
  public messageClasses={
    "text-success": !this.hasError,
    "text-danger": this.hasError,
    "text-special": this.isSpecial
  }
  public titleStyles={
    color: "blue",
    fontStyle: "italic"
  }
  onClick(){
    console.log("Hello!!!");
    this.greeting="Welcome";
  }
  onClick2(event){
    console.log(event);
    this.greeting=event.type;
  }
  constructor() { }

  ngOnInit() {
  }

  greetUser(){
    return "Hello "+this.name;
  }

  logMessage(value){
    console.log(value);
  }

}
