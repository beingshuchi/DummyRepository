import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AccordionModule } from 'primeng/components/accordion/accordion';
import { PanelModule } from 'primeng/components/panel/panel';
import { ButtonModule } from 'primeng/components/button/button';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataTableModule, InputTextModule, DropdownModule, AutoComplete, AutoCompleteModule, MenuModule, PanelMenuModule, OverlayPanelModule, CardModule } from 'primeng/primeng';

import { tableComponent } from './treaties/table.component';
import { treatiesService } from './treaties/treaties.service';
import { HttpClientModule } from '@angular/common/http'; 
import {TableModule} from 'primeng/table';
import { MenuComponent } from './treaties/menu.component';

@NgModule({
  declarations: [
    tableComponent,
    MenuComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    AccordionModule,
    PanelModule,
    ButtonModule,
    DataTableModule,
    HttpClientModule,
    ReactiveFormsModule,
    InputTextModule,
    PanelModule,
    DropdownModule,
    DropdownModule,
    AutoCompleteModule,
    PanelModule,
    MenuModule,
    PanelMenuModule,
    OverlayPanelModule,
    TableModule,
    CardModule
    
  ],
  providers: [treatiesService, HttpClientModule],
  bootstrap: [tableComponent]
})
export class AppModule { }
