import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ITreaties } from '../shared/treaties.model';
import { treatiesService } from './treaties.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MenuItem, SortEvent } from 'primeng/api';
import { IStatus } from '../shared/status.option.model';


@Component({
    selector: 'app-table',
    templateUrl: './treaties.component.html',
    styleUrls: ['./treaties.component.css']
})
export class tableComponent implements OnInit {
    items: MenuItem[];

    treatyForm: FormGroup;

    collapsed = true;


    public filtered: Map<string, boolean> = new Map<string, boolean>();
    public filter = {
        ledger: []
    };

    /*  allStatus = [
       { label : 'Study', value: 'study'},
       { label : 'Finalized', value: 'finalized'},
       { label : 'Prospect', value: 'prospect'},
       { label : 'To Validate', value: 'toValidate'},
       { label : 'Authorized', value: 'authorized'},
       { label : 'Renewed', value: 'renewed'},
       { label : 'accepted', value: 'accepted'}
     ] */


    loading: boolean;

    treaties: ITreaties[];

    allStatus: IStatus[];

    cols: any[];


    constructor(private treatiesService: treatiesService, private fb: FormBuilder) { }

    ngOnInit() {
        this.loading = true;
        setTimeout(() => {
            this.treatiesService.getTreaties().then(treaties => this.treaties = treaties);
            this.allStatus = this.treatiesService.getStatus();
            this.loading = false;
        }, 1000); 0

        this.treatyForm = this.fb.group({
            ledgerName: [''],
            uwUnit: [''],
            cedentNo: [''],
            cedentName: [''],
            treatyNo: ['', [Validators.required, Validators.minLength(1)]],
            treatyName: [[''], [Validators.required, Validators.minLength(1)]],
            treatyStatus: ['']
        })


        this.cols = [
            { field: 'ledger', header: 'Ledger' },
            { field: 'ledgerName', header: 'Ledger Name' },
            { field: 'uwUnit', header: 'Uw Unit' },
            { field: 'cedentNo', header: 'Cedent No' },
            { field: 'cedentName', header: 'Cedent Name' },
            { field: 'treatyNo', header: 'Treaty #' },
            { field: 'treatyName', header: 'Treaty Name' },
            { field: 'lastUWY', header: 'Last UWY' },
            { field: 'status', header: 'Status' }
        ];


        this.items = [
            { label: 'New', icon: 'pi pi-fw pi-plus' },
            { label: 'Open', icon: 'pi pi-fw pi-download' },
            { label: 'Undo', icon: 'pi pi-fw pi-refresh' }
        ];
    }

    pcFieldData: String;

    currentSortField: String = null;

    currentSortOrder: String = null;

    receiveSortParams({ order, fieldData }) {
        this.currentSortOrder = order;
        this.currentSortField = fieldData;

    }

    onSubmit() {
        alert(JSON.stringify(this.treatyForm.value));
    }

    hasFormError() {
        return !this.treatyForm.valid;
    }

    /*
  fieldErrors(field: string)
  {
    let controlState = this.treatyForm.controls[field];
    return (controlState.errors) ? controlState.errors:
    null;
  } */

    //treatyResults: Array = [];

    /* searchLedger(event): void {
       this.treatyResults = this.treaties.filter(c => c.ledger.startsWith(event.query));
    } */

}