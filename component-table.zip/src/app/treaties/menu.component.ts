import { Component, Output, EventEmitter, Input } from "@angular/core";
import { IStatus } from "../shared/status.option.model";
import { treatiesService } from './treaties.service';
@Component({
    selector: 'custom-menu',
    templateUrl: './menu.component.html',
    styleUrls: ['./treaties.component.css']
})
export class MenuComponent {
    allStatus: IStatus[];
    filterData = null;
    @Output() filterEvent = new EventEmitter<string>();
    @Output() sortEvent = new EventEmitter<object>();



    @Input() cFieldData: string;

    constructor(private treatiesService: treatiesService) { }

    ngOnInit() {
        this.allStatus = this.treatiesService.getStatus();
        this.allStatus.push({ label: 'All', value: '' });
    }

    emitFilterData(filterTokens) {
        console.log(filterTokens);
        this.filterEvent.emit(filterTokens);

    }

    emitAscSortEvent() {
        this.sortEvent.emit({ order: '1', fieldData: this.cFieldData });
    }
    emitDescSortEvent() {
        this.sortEvent.emit({ order: '-1', fieldData: this.cFieldData });
    }
}
