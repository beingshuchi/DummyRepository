export interface ITreaties {
    ledger?: string;
    ledgerName?: string;
    uwUnit?: number;
    cedentNo?: number;
    cedentName?: string;
    treatyNo?: number;
    treatyName?: string;
    lastUWY?: number;
    status?: string;
}
