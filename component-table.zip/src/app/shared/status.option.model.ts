export interface IStatus {
    label?: string;
    value?: string;
}
