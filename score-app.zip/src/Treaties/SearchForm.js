import React from 'react';
import { Col, Fa, FormInline,MDBCol,MDBContainer,MDBRow} from "mdbreact";
import Dropdown from 'react-dropdown';
import './search.css';

export default class SearchForm extends React.Component{

  constructor(){
    super();
    this.state={
        status:null
    };
    this.onStatusChange=this.onStatusChange.bind(this);
}

onStatusChange=(e)=>{
    const statusChange=e.value;
    this.setState({
        status: statusChange
        //status:e
    });
}

render(){

  const statusArr = [
    { label : 'Study', value: 'study'},
    { label : 'Finalized', value: 'finalized'},
    { label : 'Prospect', value: 'prospect'},
    { label : 'To Validate', value: 'To Validate'},
    { label : 'Authorized', value: 'authorized'},
    { label : 'Renewed', value: 'renewed'},
    { label : 'accepted', value: 'accepted'},
    { label : 'All', value: ''}
    ];

    return(
      <div>
          <form  class="p-grid" >
          <MDBContainer>
          <MDBRow>
          <MDBCol size='1' md="1">
                            <label class="label" for="legderName"><b>Legder</b></label><br/>
                            <Col md="1" >
                            <FormInline className="md-form">
                            <input pInputText id="ledgerName" formControlName="ledgerName" placeholder="Ledger Name" />
                            <button type="submit" className="b2">
                            <Fa icon="search" />
                            </button>
                            </FormInline>
                            </Col>
             </MDBCol>
             <MDBCol size='1' md="1">
                 <label class="label" for="uwUnit"><b>UW Unit</b></label><br/>
                 <Col md="1">
                 <FormInline class="md-form">
                 <input pInputText id="uwUnit" formControlName="uwUnit" placeholder="UW Unit Name" />
                 <button type="submit" className="b2">
                 <Fa icon="search"/>
                 </button>
                 </FormInline>
                 </Col>
             </MDBCol>

              <MDBCol size='1' md='1'>
                 <label class="label" for="cedentNo"><b>Cedent Number</b></label><br/>
                 <Col md="3">
                 <input pInputText id="cedentNo" formControlName="cedentNo" placeholder="1234" />
                 </Col>
             </MDBCol>

           
           <MDBCol size='1' md='1'>
                  <label class="label" for="cedentName"><b>Cedent Name</b></label><br/>
                  <Col md="4">
                  <input pInputText id="cedentName" formControlName="cedentName" placeholder="Cedent Name" />
                  </Col>
            </MDBCol>
                 </MDBRow>

            <MDBRow>
            <MDBCol size='1' md='1'>
                 <label class="label" for="treatyNo"><b>Treaty Number</b></label><br/>
                 <Col md="5">
                 <input pInputText id="treatyNo" formControlName="treatyNo" placeholder="Treaty Number" />
                 </Col>
            </MDBCol>
            <MDBCol size='1' md='1'>
                 <label class="label" for="treatyName"><b>Treaty Label</b></label><br/>
                 <Col md="6">
                 <input pInputText id="treatyName" formControlName="treatyName" placeholder="Treaty Label" />
                 </Col>
            </MDBCol>
            <MDBCol size='1' md='1'>
               <label class="label" for="treatyStatus"><b>Treaty Status</b></label><br/>
               <Dropdown className="b4" value={this.state.status} options={statusArr} onChange={this.onStatusChange} placeholder="Select"/>
             </MDBCol>
             </MDBRow>
             </MDBContainer>
          </form>
      </div>
    );
}
}