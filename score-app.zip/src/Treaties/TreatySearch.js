import React from 'react';
import SearchForm from './SearchForm';
import  {Fa} from "mdbreact";
import './search.css';

export class TreatySearch extends React.Component{
    render(){
        return (
            <div><h3>Treaty Search</h3>
              <div >
                <button type="reset" className="b1" >Reset fields</button>
              </div>
              <SearchForm />
              <div >
              <button type="submit" className="b3">
              <Fa icon="search" />
              </button>
             </div>


            </div>
        );
        
    }
}

export default TreatySearch;