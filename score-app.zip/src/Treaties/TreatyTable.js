import React from 'react';
import PropTypes from 'prop-types'
import {DataTable} from 'primereact/components/datatable/DataTable';
import {Column} from 'primereact/components/column/Column';
import {TableService} from './TableService';

export default class TreatyTable extends React.Component{
    constructor(){
        super();
        this.state={data:[]};
        this.tableService= new TableService();
    }

    componentDidMount(){
        this.tableService.getSampleData().then(data=>this.setState({datas:data}));
    }

    render(){
        const columns = [
            {field: 'ledger', header: 'Legder'},
            {field: 'ledgerName', header: 'Ledger Name'},
            {field: 'uwUnit', header: 'UW Unit'},
            {field: 'cedentNo', header: 'Credent No'},
            {field: 'cedentName', header: 'Credent Name'},
            {field: 'treatyNo', header: 'Treaty No'},
            {field: 'treatyName', header: 'Treaty Name'},
            {field: 'lastUWY', header: 'Last UWY'},
            {field: 'status', header: 'Status'}
        ];
        const dynamicColumns= columns.map((col,i)=>{
            return <Column key={col.field} field={col.field} header={col.header}/>
        });
        return (
            <div>
                <DataTable value={this.state.data}>
                {dynamicColumns}
                </DataTable>
                
            </div>
        );
    }
}

TreatyTable.prototypes ={
    ledger : PropTypes.string.isRequired,
    ledgerName :  PropTypes.string.isRequired,
    uwUnit:  PropTypes.number.isRequired,
    cedentNo:  PropTypes.number.isRequired,
    cedentName:  PropTypes.string.isRequired,
    treatyNo:  PropTypes.number.isRequired,
    treatyName:  PropTypes.string.isRequired,
    lastUWY:  PropTypes.number.isRequired,
    status:  PropTypes.string.isRequired
};