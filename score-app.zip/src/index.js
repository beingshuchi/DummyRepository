import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import TreatySearch from './Treaties/TreatySearch';
import TreatyTable from './Treaties/TreatyTable';
import * as serviceWorker from './serviceWorker';

ReactDOM.render(<TreatySearch />, document.getElementById('search'));
ReactDOM.render(<TreatyTable />, document.getElementById('table'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister();
