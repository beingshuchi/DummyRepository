
export default function(){
    return [
        {
            id:1,
            first:"shuchita",
            last:"mehra",
            age:45,
            description: "Shuchita is a full stack developer",
           // thumbnail: "http://i.imgur.com/7yUvePI.jpg"
        },
        {
            id:2,
            first:"Yuan",
            last:"Pant",
            age:44,
            description: "Yuan loves to work on Java related projects",
            //thumbnail: "http://i.imgur.com/52xRlm8.png"
        },
        {
            id:3,
            first:"Maddy",
            last:"willson",
            age:35,
            description: "Maddy likes her dog joey",
            //thumbnail: "http://i.imgur.com/4EMtxHB.png"
        }
    ]
}